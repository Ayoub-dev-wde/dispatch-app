<?php
// Load the database connection
require_once __DIR__ . '/inc/db_connect.php';
?>
