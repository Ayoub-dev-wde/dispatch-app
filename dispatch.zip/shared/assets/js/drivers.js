// Handle image preview when a driver photo is selected
function handlePhotoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = e => {
        const preview = document.getElementById('preview');
        if (preview && preview.tagName === 'IMG') {
            preview.src = e.target.result;
        } else if (preview) {
            // Replace placeholder with uploaded image
            const img = document.createElement('img');
            img.id = 'preview';
            img.width = 150;
            img.src = e.target.result;
            preview.replaceWith(img);
        }
    };
    reader.readAsDataURL(file);
}

// Attach file input change events
function setupPhotoUpload() {
    const photoInputs = document.querySelectorAll('input[name="photo_id"]');
    photoInputs.forEach(input => {
        input.removeEventListener('change', handlePhotoUpload); // ensure no duplicate handlers
        input.addEventListener('change', handlePhotoUpload);
    });
}

// Handle form submission for driver add/edit
function setupDriverFormHandler(formId, redirectAfterSuccess = false) {
    const form = document.getElementById(formId);
    if (!form) return;

    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const formData = new FormData(form);
        const notification = document.getElementById('notification');
        if (notification) {
            notification.style.display = 'none';
            notification.className = 'notification';
        }

        try {
            const res = await fetch(form.action || location.href, {
                method: 'POST',
                body: formData
            });
            const json = await res.json();

            if (notification) {
                notification.textContent = json.message || '';
                notification.classList.add(json.success ? 'success' : 'error');
                notification.style.display = 'block';
            }

            if (json.success && redirectAfterSuccess) {
                setTimeout(() => {
                    window.location.href = 'index.php';
                }, 1500);
            }
        } catch (error) {
            if (notification) {
                notification.textContent = 'Erreur de communication avec le serveur.';
                notification.classList.add('error');
                notification.style.display = 'block';
            }
        }
    });
}

// Confirmation before deleting a driver
function setupDeleteLinks() {
    document.querySelectorAll('.delete-link').forEach(link => {
        link.addEventListener('click', function (e) {
            if (!confirm('Voulez-vous vraiment supprimer ce chauffeur ?')) {
                e.preventDefault();
            }
        });
    });
}

// DOM ready init
document.addEventListener('DOMContentLoaded', function () {
    setupPhotoUpload();
    setupDeleteLinks();

    const driverForm = document.getElementById('driverForm');
    if (driverForm) {
        const isAddPage = window.location.pathname.includes('add.php');
        setupDriverFormHandler('driverForm', isAddPage);
    }
});
