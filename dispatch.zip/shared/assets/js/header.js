document.addEventListener('DOMContentLoaded', () => {
  // Sidebar toggle
  const toggleBtn = document.querySelector('.toggle-sidebar-btn');
  const sidebarMenu = document.getElementById('sidebar');
  const pageWrapper = document.getElementById('page-wrapper');

  toggleBtn?.addEventListener('click', () => {
    sidebarMenu?.classList.toggle('active');
    pageWrapper?.classList.toggle('sidebar-open');

    const isOpen = sidebarMenu?.classList.contains('active');
    toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    sidebarMenu?.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
  });

  // Close sidebar when clicking outside (mobile)
  document.addEventListener('click', (e) => {
    if (
      sidebarMenu?.classList.contains('active') &&
      !sidebarMenu.contains(e.target) &&
      !toggleBtn.contains(e.target)
    ) {
      sidebarMenu.classList.remove('active');
      sidebarMenu.setAttribute('aria-hidden', 'true');
      pageWrapper.classList.remove('sidebar-open');
      toggleBtn.setAttribute('aria-expanded', 'false');
    }
  });

  // Language switcher
  const langSelect = document.getElementById('langSelect');
  if (langSelect) {
    const urlParams = new URLSearchParams(window.location.search);
    const currentLang = urlParams.get('lang');
    if (currentLang && [...langSelect.options].some(o => o.value === currentLang)) {
      langSelect.value = currentLang;
    }

    langSelect.addEventListener('change', () => {
      const lang = langSelect.value;
      const url = new URL(window.location.href);
      url.searchParams.set('lang', lang);
      window.location.href = url.toString();
    });
  }

  // Settings dropdown toggle
  const settingsBtn = document.getElementById('settingsDropdown');
  const settingsMenu = document.getElementById('settingsMenu');

  if (settingsBtn && settingsMenu) {
    settingsBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isShown = settingsMenu.classList.toggle('show');
      settingsBtn.setAttribute('aria-expanded', isShown ? 'true' : 'false');
    });

    document.addEventListener('click', (e) => {
      if (
        settingsMenu.classList.contains('show') &&
        !settingsMenu.contains(e.target) &&
        !settingsBtn.contains(e.target)
      ) {
        settingsMenu.classList.remove('show');
        settingsBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Notifications
  const bell = document.getElementById('notifBell');
  const dropdown = document.getElementById('notifDropdown');
  const notifCount = document.getElementById('notifCount');

  function loadNotifications() {
    fetch('/dispatch/admin/api/get_notifications.php')
      .then(res => res.json())
      .then(data => {
        dropdown.innerHTML = '';

        if (!data.length) {
          dropdown.innerHTML = '<li role="menuitem">Aucune notification</li>';
          notifCount.textContent = '0';
          notifCount.style.display = 'none';
          return;
        }

        let unreadCount = 0;
        data.forEach(n => {
          const li = document.createElement('li');
          li.textContent = `${n.message} – ${new Date(n.created_at).toLocaleString()}`;
          li.setAttribute('role', 'menuitem');
          dropdown.appendChild(li);
          if (n.is_read === 0 || n.is_read === undefined) unreadCount++;
        });

        notifCount.textContent = unreadCount;
        notifCount.style.display = unreadCount > 0 ? 'inline-block' : 'none';
      })
      .catch(err => {
        console.error('Erreur notifications :', err);
      });
  }

  loadNotifications();
  setInterval(loadNotifications, 30000);

  bell?.addEventListener('click', (e) => {
    e.stopPropagation();
    const isShown = dropdown.classList.toggle('show');
    bell.setAttribute('aria-expanded', isShown);

    if (isShown) {
      fetch('/dispatch/admin/api/mark_notifications_read.php', { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            notifCount.textContent = '0';
            notifCount.style.display = 'none';
            loadNotifications();
          }
        });
    }
  });

  // ✅ CLOSE NOTIFICATIONS IF CLICKED OUTSIDE
  document.addEventListener('click', (e) => {
    if (
      dropdown.classList.contains('show') &&
      !bell.contains(e.target) &&
      !dropdown.contains(e.target)
    ) {
      dropdown.classList.remove('show');
      bell.setAttribute('aria-expanded', 'false');
    }
  });
});
