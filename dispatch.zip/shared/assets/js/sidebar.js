document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.querySelector('.toggle-sidebar-btn');
  const sidebarMenu = document.getElementById('sidebar');
  const pageWrapper = document.getElementById('page-wrapper');

  toggleBtn?.addEventListener('click', () => {
    sidebarMenu.classList.toggle('active');
    pageWrapper.classList.toggle('sidebar-open');

    const isOpen = sidebarMenu.classList.contains('active');
    sidebarMenu.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
  });

  document.addEventListener('click', (e) => {
    if (
      sidebarMenu.classList.contains('active') &&
      !sidebarMenu.contains(e.target) &&
      !toggleBtn.contains(e.target)
    ) {
      sidebarMenu.classList.remove('active');
      sidebarMenu.setAttribute('aria-hidden', 'true');
      pageWrapper.classList.remove('sidebar-open');
    }
  });
});
