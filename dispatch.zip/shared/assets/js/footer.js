// /dispatch/assets/js/footer.js

document.addEventListener('DOMContentLoaded', function () {
    // Sidebar toggle logic
    const btn = document.querySelector('.toggle-sidebar-btn');
    const sidebar = document.getElementById('sidebar');

    if (btn && sidebar) {
        btn.addEventListener('click', function () {
            const expanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', !expanded);
            sidebar.classList.toggle('visible');
        });
    }

    // Notification bell toggle logic
    const notifBell = document.getElementById('notifBell');
    const notifDropdown = document.getElementById('notifDropdown');

    if (notifBell && notifDropdown) {
        notifBell.addEventListener('click', function () {
            const expanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', !expanded);
            notifDropdown.style.display = expanded ? 'none' : 'block';
        });
    }
});
