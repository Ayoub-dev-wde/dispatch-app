document.addEventListener('DOMContentLoaded', () => {
  const notifBell = document.getElementById('notifBell');
  const notifDropdown = document.getElementById('notifDropdown');
  const notifCount = document.getElementById('notifCount');
  const notifList = document.getElementById('notifList');

  // Vérifie si les éléments existent avant d'initialiser la logique
  const hasNotifElements = notifBell && notifDropdown && notifCount && notifList;

  if (hasNotifElements) {
    notifBell.addEventListener('click', (e) => {
      e.stopPropagation(); // Empêche la propagation pour éviter fermeture immédiate

      const isVisible = notifDropdown.style.display === 'block';
      notifDropdown.style.display = isVisible ? 'none' : 'block';

      if (!isVisible) fetchNotifications();
    });

    // Ferme la dropdown si on clique en dehors
    document.addEventListener('click', (e) => {
      if (!notifBell.contains(e.target) && !notifDropdown.contains(e.target)) {
        notifDropdown.style.display = 'none';
      }
    });

    function fetchNotifications() {
      fetch('/dispatch/webhooks/get_notifications.php')
        .then(res => res.json())
        .then(data => {
          notifList.innerHTML = '';

          if (!data.length) {
            notifList.innerHTML = '<li>Aucune notification</li>';
            notifCount.textContent = '0';
            notifCount.style.display = 'none';
            return;
          }

          data.forEach(notif => {
            const li = document.createElement('li');
            li.textContent = `${notif.created_at} - ${notif.message}`;
            notifList.appendChild(li);
          });

          notifCount.textContent = data.length;
          notifCount.style.display = 'inline-block';
        })
        .catch(err => {
          console.error('Erreur fetch notifications:', err);
        });
    }

    // Premier chargement
    fetchNotifications();

    // Rafraîchir toutes les 30 secondes
    setInterval(fetchNotifications, 30000);
  } else {
    console.warn('Element(s) manquant(s) dans le DOM pour les notifications');
  }
});
