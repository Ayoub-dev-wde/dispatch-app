document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('searchInput');
  const rows = document.querySelectorAll('.trips-table tbody tr');

  if (!searchInput) {
    console.error('Live search input not found');
    return;
  }

  if (!rows.length) {
    console.warn('No trip rows found');
    return;
  }

  searchInput.addEventListener('input', () => {
    const filter = searchInput.value.trim().toLowerCase();

    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      const match = text.includes(filter);
      row.style.display = match ? '' : 'none';
    });

    // Optional: Show "no results" message if all are hidden
    const anyVisible = Array.from(rows).some(row => row.style.display !== 'none');
    const noResultsMessageId = 'noResultsMessage';
    let noResultsMessage = document.getElementById(noResultsMessageId);

    if (!anyVisible) {
      if (!noResultsMessage) {
        noResultsMessage = document.createElement('tr');
        noResultsMessage.id = noResultsMessageId;
        noResultsMessage.innerHTML = `<td colspan="7" style="text-align: center;">Aucun résultat trouvé</td>`;
        document.querySelector('.trips-table tbody').appendChild(noResultsMessage);
      }
    } else {
      const existingMessage = document.getElementById(noResultsMessageId);
      if (existingMessage) existingMessage.remove();
    }
  });
});
