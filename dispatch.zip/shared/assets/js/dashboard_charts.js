
document.addEventListener("DOMContentLoaded", function () {
  const labels = window.dashboardData.labels;
  const tripData = window.dashboardData.tripData;
  const revenueData = window.dashboardData.revenueData;
  const cod = window.dashboardData.cod;
  const online = window.dashboardData.online;
  const driverNames = window.dashboardData.driverNames;
  const driverCounts = window.dashboardData.driverCounts;

  const chartMap = {
    chauffeurs: {
      label: 'Courses par Chauffeur (7 jours)',
      data: driverCounts,
      labels: driverNames,
      backgroundColor: 'rgba(54, 162, 235, 0.7)',
      borderColor: 'rgba(54, 162, 235, 1)',
      type: 'bar'
    },
    revenue: {
      label: 'Revenus (€)',
      data: revenueData,
      labels: labels,
      backgroundColor: 'rgba(75,192,192,0.6)',
      borderColor: 'rgba(75,192,192,1)',
      type: 'line'
    },
    dispatch: {
      label: 'Courses Dispatchées',
      data: tripData,
      labels: labels,
      backgroundColor: 'rgba(54,162,235,0.6)',
      borderColor: 'rgba(54,162,235,1)',
      type: 'line'
    },
    cod: {
      label: 'Paiement à bord (€)',
      data: Array(7).fill(cod / 7),
      labels: labels,
      backgroundColor: 'rgba(255,159,64,0.6)',
      borderColor: 'rgba(255,159,64,1)',
      type: 'line'
    },
    online: {
      label: 'Paiement en ligne (€)',
      data: Array(7).fill(online / 7),
      labels: labels,
      backgroundColor: 'rgba(153,102,255,0.6)',
      borderColor: 'rgba(153,102,255,1)',
      type: 'line'
    }
  };

  let currentChartKey = 'revenue';
  const ctx = document.getElementById('mainChart').getContext('2d');
  const chartContainer = document.querySelector('.charts-section');
  chartContainer.classList.remove('active');

  let chart = new Chart(ctx, {
    type: chartMap[currentChartKey].type,
    data: {
      labels: chartMap[currentChartKey].labels,
      datasets: [{
        label: chartMap[currentChartKey].label,
        data: chartMap[currentChartKey].data,
        backgroundColor: chartMap[currentChartKey].backgroundColor,
        borderColor: chartMap[currentChartKey].borderColor,
        borderWidth: 1,
        fill: chartMap[currentChartKey].type === 'line',
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });

  document.querySelectorAll('.stat-card.clickable').forEach(card => {
    card.addEventListener('click', () => {
      const key = card.getAttribute('data-chart');
      if (!chartMap[key]) return;
      currentChartKey = key;

      chart.destroy();

      chart = new Chart(ctx, {
        type: chartMap[key].type,
        data: {
          labels: chartMap[key].labels,
          datasets: [{
            label: chartMap[key].label,
            data: chartMap[key].data,
            backgroundColor: chartMap[key].backgroundColor,
            borderColor: chartMap[key].borderColor,
            borderWidth: 1,
            fill: chartMap[key].type === 'line',
            tension: 0.3
          }]
        },
        options: {
          responsive: true,
          scales: {
            y: { beginAtZero: true }
          }
        }
      });

      chartContainer.classList.add('active');
    });
  });
});

