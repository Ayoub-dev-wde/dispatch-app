<?php
$pageTitle      = $pageTitle      ?? '';
$breadcrumbs    = $breadcrumbs    ?? [];
$showBackButton = $showBackButton ?? false;

// Remove duplicate title from breadcrumbs if it exists
if (!empty($pageTitle)) {
    $lastCrumb = end($breadcrumbs);
    if ($lastCrumb && isset($lastCrumb['label']) && trim($lastCrumb['label']) === trim($pageTitle)) {
        array_pop($breadcrumbs);
    }
}

// Auto-detect subpage: if breadcrumbs still have 2+ items → subpage
$isSubPage = count($breadcrumbs) > 1;
?>

<div class="page-header page-header-light">
    <div class="d-flex justify-content-between align-items-center flex-wrap flex-md-nowrap">
        
        <?php if (!$isSubPage && $pageTitle): ?>
            <div class="page-title d-flex align-items-center mr-4">
                <h4 class="mb-0 d-flex align-items-center">
                    <i class="icon-stack mr-2" aria-hidden="true"></i>
                    <?= htmlspecialchars($pageTitle) ?>
                </h4>
            </div>
        <?php endif; ?>

        <?php if ($breadcrumbs): ?>
            <nav class="breadcrumbs d-flex align-items-center" aria-label="breadcrumb">
                <?php foreach ($breadcrumbs as $i => $crumb): ?>
                    <?php if (!empty($crumb['url'])): ?>
                        <a href="<?= htmlspecialchars($crumb['url']) ?>"><?= htmlspecialchars($crumb['label']) ?></a>
                    <?php else: ?>
                        <span><?= htmlspecialchars($crumb['label']) ?></span>
                    <?php endif; ?>
                    <?php if ($i < count($breadcrumbs) - 1): ?> &gt; <?php endif; ?>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>

        
        
    </div>
</div>

<link rel="stylesheet" href="/dispatch/shared/assets/css/subheader.css">
<script src="/dispatch/shared/assets/js/header.js" defer></script>
