<?php $isAuthPage = $isAuthPage ?? false; ?>

</main> <!-- Close #main-content -->

<?php if (!$isAuthPage): ?>
</div> <!-- Close #page-wrapper -->
<?php endif; ?>

<!-- External Scripts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="/dispatch/shared/assets/js/footer.js?v=<?php echo filemtime(__DIR__ . '/../../assets/js/footer.js'); ?>" defer></script>

</body>
</html>
