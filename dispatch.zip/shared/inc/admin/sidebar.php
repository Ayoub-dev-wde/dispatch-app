<?php if (!$isAuthPage): ?>
<?php
  $currentPage = basename($_SERVER['PHP_SELF']);
  $lang = $_SESSION['lang'] ?? 'fr';

  // Label translations
  $labels = [
    'fr' => [
      'dashboard' => 'Tableau de Bord',
      'drivers' => 'Chauffeurs',
      'vehicles' => 'Véhicules',
      'trips' => 'Courses',
      'accounts' => 'Comptes',
      'reports' => 'Rapports',
      'users' => 'Utilisateurs',
      'logout' => 'Déconnexion',
    ],
    'en' => [
      'dashboard' => 'Dashboard',
      'drivers' => 'Drivers',
      'vehicles' => 'Vehicles',
      'trips' => 'Trips',
      'accounts' => 'Accounts',
      'reports' => 'Reports',
      'users' => 'Users',
      'logout' => 'Logout',
    ]
  ];
  $L = $labels[$lang];
?>

<div id="sidebar">
  
  <ul class="sidebar-nav" aria-label="Main Navigation">
      <li class="sidebar-section">Menu</li>
    <li><a href="/dispatch/admin/dashboard.php" class="sidebar-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-chart-line"></i> <?= $L['dashboard'] ?></a></li>
    
    <li class="sidebar-section">Gestion</li>
    <li><a href="/dispatch/admin/drivers/index.php" class="sidebar-link <?= $currentPage === 'index.php' && strpos($_SERVER['REQUEST_URI'], '/drivers/') !== false ? 'active' : '' ?>"><i class="fas fa-id-badge"></i> <?= $L['drivers'] ?></a></li>
    <li><a href="/dispatch/admin/vehicles/index.php" class="sidebar-link <?= $currentPage === 'index.php' && strpos($_SERVER['REQUEST_URI'], '/vehicles/') !== false ? 'active' : '' ?>"><i class="fas fa-car-side"></i> <?= $L['vehicles'] ?></a></li>
    <li><a href="/dispatch/admin/trips/index.php" class="sidebar-link <?= $currentPage === 'index.php' && strpos($_SERVER['REQUEST_URI'], '/trips/') !== false ? 'active' : '' ?>"><i class="fas fa-route"></i> <?= $L['trips'] ?></a></li>
    <li><a href="/dispatch/admin/accounts/index.php" class="sidebar-link <?= $currentPage === 'index.php' && strpos($_SERVER['REQUEST_URI'], '/accounts/') !== false ? 'active' : '' ?>"><i class="fas fa-wallet"></i> <?= $L['accounts'] ?></a></li>

    <!-- Future sections -->
    <!--
    <li class="sidebar-section">Administration</li>
    <li><a href="/dispatch/reports/index.php" class="sidebar-link"><i class="fas fa-chart-pie"></i> <?= $L['reports'] ?></a></li>
    <li><a href="/dispatch/admin/users/index.php" class="sidebar-link"><i class="fas fa-users-cog"></i> <?= $L['users'] ?></a></li>
    -->

    <li class="sidebar-section">Session</li>
    <li><a href="/dispatch/admin/logout.php" class="sidebar-link"><i class="fas fa-sign-out-alt"></i> <?= $L['logout'] ?></a></li>
  </ul>
</div>
    <link rel="stylesheet" href="/dispatch/shared/assets/css/sidebar.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<?php endif; ?>
