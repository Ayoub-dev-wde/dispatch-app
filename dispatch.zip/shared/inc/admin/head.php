<?php
require_once __DIR__ . '/../db_connect.php';

$currentPage = basename($_SERVER['PHP_SELF']);
$isAuthPage = in_array($currentPage, ['login.php', 'register.php']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BrusselRide Dispatch</title>

    <!-- Favicon -->
    <link rel="icon" href="/dispatch/shared/assets/images/favicon.ico" type="image/x-icon" />

    <!-- Global Styles -->
    <link rel="stylesheet" href="/dispatch/shared/assets/css/styles.css" />

    <!-- Drivers -->
    <link rel="stylesheet" href="/dispatch/shared/assets/css/drivers.css" />

    <!-- Dashboard Styles (only on dashboard.php) -->
    <?php if ($currentPage === 'dashboard.php'): ?>
        <link rel="stylesheet" href="/dispatch/shared/assets/css/main_dashboard.css" />
    <?php endif; ?>

    <!-- Accounts styles -->
    <link rel="stylesheet" href="/dispatch/shared/assets/css/accounts.css" />

    <!-- Trips styles -->
    <link rel="stylesheet" href="/dispatch/shared/assets/css/trips.css" />

    <!-- Font Awesome -->
    <link 
  rel="stylesheet" 
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" 
  integrity="sha512-Avb2QiuDEEvB4bZJYdft2mNjVShBftLdPG8FJ0V7irTLQ8Uo0qcPxh4Plq7G5tGm0rU+1SPhVotteLpBERwTkw==" 
  crossorigin="anonymous" 
  referrerpolicy="no-referrer" />


    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />

   

    <!-- SEO Meta -->
    <meta name="description" content="BrusselRide Dispatch - A complete solution for managing trips and drivers" />
    <meta name="keywords" content="dispatch, trips, drivers, transport, admin" />
    <meta name="author" content="Your Name or Company" />
</head>
<body class="<?= $isAuthPage ? 'auth' : 'with-sidebar' ?>">
