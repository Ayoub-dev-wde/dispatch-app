<?php
require_once __DIR__ . '/PasswordHash.php';

function wp_check_password($password, $hash) {
    $wp_hasher = new PasswordHash(8, true);
    return $wp_hasher->CheckPassword($password, $hash);
}
