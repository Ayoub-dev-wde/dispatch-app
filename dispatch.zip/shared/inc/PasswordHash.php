<?php
/**
 * Portable PHP password hashing framework.
 * Based on phpass by Solar Designer
 */

class PasswordHash {
    private $itoa64;
    private $iteration_count_log2;
    private $portable_hashes;
    private $random_state;

    public function __construct($iteration_count_log2, $portable_hashes) {
        $this->itoa64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $this->iteration_count_log2 = $iteration_count_log2;
        $this->portable_hashes = $portable_hashes;
        $this->random_state = microtime() . uniqid(rand(), TRUE);
    }

    private function get_random_bytes($count) {
        $output = '';
        if (function_exists('random_bytes')) {
            return random_bytes($count);
        }
        if (function_exists('openssl_random_pseudo_bytes')) {
            $output = openssl_random_pseudo_bytes($count);
        }
        if ($output === '' || strlen($output) < $count) {
            $output = '';
            for ($i = 0; $i < $count; $i += 16) {
                $this->random_state =
                    md5(microtime() . $this->random_state);
                $output .=
                    pack('H*', md5($this->random_state));
            }
            $output = substr($output, 0, $count);
        }
        return $output;
    }

    private function encode64($input, $count) {
        $output = '';
        $i = 0;
        do {
            $value = ord($input[$i++]);
            $output .= $this->itoa64[$value & 0x3f];
            if ($i < $count) {
                $value |= ord($input[$i]) << 8;
            }
            $output .= $this->itoa64[($value >> 6) & 0x3f];
            if ($i++ >= $count) {
                break;
            }
            if ($i < $count) {
                $value |= ord($input[$i]) << 16;
            }
            $output .= $this->itoa64[($value >> 12) & 0x3f];
            if ($i++ >= $count) {
                break;
            }
            $output .= $this->itoa64[($value >> 18) & 0x3f];
        } while ($i < $count);
        return $output;
    }

    private function gensalt_private($input) {
        $iteration_count_log2 = min(max($this->iteration_count_log2, 4), 31);
        $output = '$P$';
        $output .= $this->itoa64[$iteration_count_log2];
        $output .= $this->encode64($input, 6);
        return $output;
    }

    private function crypt_private($password, $setting) {
        $output = '*0';
        if (substr($setting, 0, 2) === '*0') {
            $output = '*1';
        }

        if (substr($setting, 0, 3) !== '$P$') {
            return $output;
        }

        $count_log2 = strpos($this->itoa64, $setting[3]);
        if ($count_log2 < 7 || $count_log2 > 30) {
            return $output;
        }

        $count = 1 << $count_log2;

        $salt = substr($setting, 4, 8);
        if (strlen($salt) !== 8) {
            return $output;
        }

        $hash = md5($salt . $password, TRUE);
        do {
            $hash = md5($hash . $password, TRUE);
        } while (--$count);

        $output = substr($setting, 0, 12);
        $output .= $this->encode64($hash, 16);

        return $output;
    }

    public function HashPassword($password) {
        $random = $this->get_random_bytes(6);
        $salt = $this->gensalt_private($random);
        $hash = $this->crypt_private($password, $salt);
        if (strlen($hash) === 34) {
            return $hash;
        }
        return '*';
    }

    public function CheckPassword($password, $stored_hash) {
        $hash = $this->crypt_private($password, $stored_hash);
        return hash_equals($stored_hash, $hash);
    }
}
