<?php if (!$isAuthPage): ?>
<?php
  $currentPage = basename($_SERVER['PHP_SELF']);
  $currentUri = $_SERVER['REQUEST_URI'];
  $lang = $_SESSION['lang'] ?? 'fr';

  $labels = [
    'fr' => [
      'dashboard' => 'Tableau de Bord',
      'tripsMenu' => 'Courses',
      'availableTrips' => 'Courses Disponibles',
      'myTrips' => 'Mes Courses',
      'tripHistory' => 'Historique des Courses',
      'profile' => 'Mon Profil',
      'logout' => 'Déconnexion',
    ],
    'en' => [
      'dashboard' => 'Dashboard',
      'tripsMenu' => 'Trips',
      'availableTrips' => 'Available Trips',
      'myTrips' => 'My Trips',
      'tripHistory' => 'Trip History',
      'profile' => 'My Profile',
      'logout' => 'Logout',
    ]
  ];
  $L = $labels[$lang];

  // Expand submenu if in /trips/
  $isTripsSection = strpos($currentUri, '/trips/') !== false;
?>

<div id="sidebar">
  <ul class="sidebar-nav" aria-label="Navigation Chauffeur">
    <li class="sidebar-section">Menu</li>
    <li>
      <a href="/dispatch/passenger/dashboard.php" class="sidebar-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
        <i class="fas fa-home"></i> <?= $L['dashboard'] ?>
      </a>
    </li>

    <li class="sidebar-section"><?= $L['tripsMenu'] ?></li>
    <li class="has-submenu <?= $isTripsSection ? 'open' : '' ?>">
      <a href="#" class="sidebar-link">
        <i class="fas fa-route"></i> <?= $L['tripsMenu'] ?> <i class="fas fa-chevron-down submenu-toggle-icon"></i>
      </a>
      <ul class="submenu">
        <li>
          <a href="/dispatch/driver/trips/available.php"
             class="<?= $currentPage === 'available.php' ? 'active' : '' ?>">
             <i class="fas fa-search-location"></i> <?= $L['availableTrips'] ?>
          </a>
        </li>
        <li>
          <a href="/dispatch/driver/trips/index.php"
             class="<?= $currentPage === 'index.php' && $isTripsSection ? 'active' : '' ?>">
             <i class="fas fa-car"></i> <?= $L['myTrips'] ?>
          </a>
        </li>
        <li>
          <a href="/dispatch/driver/trips/history.php"
             class="<?= $currentPage === 'history.php' ? 'active' : '' ?>">
             <i class="fas fa-history"></i> <?= $L['tripHistory'] ?>
          </a>
        </li>
      </ul>
    </li>

    <li class="sidebar-section">Mes Informations</li>
    <li>
      <a href="/dispatch/driver/profile.php" class="sidebar-link <?= $currentPage === 'profile.php' ? 'active' : '' ?>">
        <i class="fas fa-user-circle"></i> <?= $L['profile'] ?>
      </a>
    </li>

    <li class="sidebar-section">Session</li>
    <li>
      <a href="/dispatch/driver/logout.php" class="sidebar-link">
        <i class="fas fa-sign-out-alt"></i> <?= $L['logout'] ?>
      </a>
    </li>
  </ul>
</div>

<link rel="stylesheet" href="/dispatch/shared/assets/css/sidebar.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<script>
  // Toggle submenu
  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".has-submenu > a").forEach(link => {
      link.addEventListener("click", e => {
        e.preventDefault();
        link.parentElement.classList.toggle("open");
      });
    });
  });
</script>
<?php endif; ?>
