<?php
function log_error($message) {
    file_put_contents(__DIR__ . '/../logs/errors.log', date('[Y-m-d H:i:s] ') . $message . PHP_EOL, FILE_APPEND);
}

function log_sync($type, $stats) {
    $db = $GLOBALS['mysqli'];
    $stmt = $db->prepare("INSERT INTO sync_logs (sync_type, records_processed, new_records, errors) VALUES (?, ?, ?, ?)");
    $processed = $stats['imported'] + $stats['updated'] + $stats['skipped'];
    $stmt->bind_param("siii", $type, $processed, $stats['imported'], $stats['errors']);
    $stmt->execute();
}