<?php
require_once __DIR__ . '/../db_connect.php';

$currentPage = basename($_SERVER['PHP_SELF']);
$isAuthPage = in_array($currentPage, ['login.php', 'register.php']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BrusselRide - Espace Chauffeur</title>

    <!-- Favicon -->
    <link rel="icon" href="/dispatch/shared/assets/images/favicon.ico" type="image/x-icon" />

    <!-- Global Styles -->
    <link rel="stylesheet" href="/dispatch/shared/assets/css/styles.css" />

    <!-- Chauffeurs -->
    <link rel="stylesheet" href="/dispatch/shared/assets/css/driver.css" />

    <!-- Font Awesome -->
    <link 
      rel="stylesheet" 
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" 
      integrity="sha512-Avb2QiuDEEvB4bZJYdft2mNjVShBftLdPG8FJ0V7irTLQ8Uo0qcPxh4Plq7G5tGm0rU+1SPhVotteLpBERwTkw==" 
      crossorigin="anonymous" 
      referrerpolicy="no-referrer" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />

    <!-- SEO Meta -->
    <meta name="description" content="Espace Chauffeur - BrusselRide Dispatch" />
    <meta name="keywords" content="chauffeur, courses, transport, espace personnel" />
    <meta name="author" content="BrusselRide" />
</head>
<body class="<?= $isAuthPage ? 'auth' : 'with-sidebar' ?>">
