<?php
$pageTitle = "Paramètres du profil";
$breadcrumbs = [];
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// settings.php
require_once __DIR__ . '/db_connect.php';

// Start session and check user logged in
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit;
}
$userId = $_SESSION['user_id'];

// Initialize error and success messages
$error = "";
$success = "";

// Fetch user data
function fetchUser($conn, $userId) {
    $stmt = $conn->prepare("SELECT * FROM dispatch_user WHERE id=?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    return $user;
}

// Fetch billing data
function fetchBilling($conn, $userId) {
    $stmt = $conn->prepare("SELECT * FROM dispatch_user_billing WHERE user_id=?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $billing = $result->fetch_assoc();
    $stmt->close();
    return $billing ?: [];
}

$user = fetchUser($conn, $userId);
$billing = fetchBilling($conn, $userId);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitize inputs
    $salutation    = trim($_POST['salutation'] ?? '');
    $first_name    = trim($_POST['first_name'] ?? '');
    $last_name     = trim($_POST['last_name'] ?? '');
    $gender        = trim($_POST['gender'] ?? '');
    $ui_language   = trim($_POST['ui_language'] ?? '');
    $currency      = trim($_POST['currency'] ?? '');
    $email_alt     = trim($_POST['email_alt'] ?? '');
    $company_name  = trim($_POST['company_name'] ?? '');
    $default_lang  = $ui_language;

    $password      = $_POST['password'] ?? '';

    // **Added fields:**
    $phone_primary    = trim($_POST['phone_primary'] ?? '');
    $phone_secondary  = trim($_POST['phone_secondary'] ?? '');
    $site_title       = trim($_POST['site_title'] ?? '');

    // Billing info
    $company_vat    = trim($_POST['company_vat'] ?? '');
    $company_number = trim($_POST['company_number'] ?? '');
    $tax_number     = trim($_POST['tax_number'] ?? '');
    $company_address= trim($_POST['company_address'] ?? '');
    $city           = trim($_POST['city'] ?? '');
    $country        = trim($_POST['country'] ?? '');
    $postcode       = trim($_POST['postcode'] ?? '');
    $contact_email  = trim($_POST['contact_email'] ?? '');
    $contact_name   = trim($_POST['contact_name'] ?? '');

    // Handle photo upload if exists
    $photo_path = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/admin/profile_photos/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $fileTmp = $_FILES['photo']['tmp_name'];
        $fileName = basename($_FILES['photo']['name']);
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($ext, $allowed)) {
            $error = "Format de photo non autorisé. Formats autorisés: jpg, jpeg, png, gif.";
        } else {
            $newFileName = 'user_' . $userId . '_' . time() . '.' . $ext;
            $dest = $uploadDir . $newFileName;
            if (move_uploaded_file($fileTmp, $dest)) {
                $photo_path = 'uploads/admin/profile_photos/' . $newFileName; // relative path for DB
            } else {
                $error = "Erreur lors du téléchargement de la photo.";
            }
        }
    }

    if (!$error) {
        // Password hash if changed
        $hashed_password = null;
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        }

        // Prepare update for dispatch_user
        $sql = "UPDATE dispatch_user SET salutation=?, first_name=?, last_name=?, gender=?, ui_language=?, currency=?, email_alt=?, company_name=?, default_lang=?, phone_primary=?, phone_secondary=?, site_title=?";
        $params = [$salutation, $first_name, $last_name, $gender, $ui_language, $currency, $email_alt, $company_name, $default_lang, $phone_primary, $phone_secondary, $site_title];
        $types = "ssssssssssss";

        if ($photo_path !== null) {
            $sql .= ", photo_path=?";
            $params[] = $photo_path;
            $types .= "s";
        }
        if ($hashed_password !== null) {
            $sql .= ", password=?";
            $params[] = $hashed_password;
            $types .= "s";
        }
        $sql .= " WHERE id=?";
        $params[] = $userId;
        $types .= "i";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            $error = "Erreur préparation requête: " . $conn->error;
        } else {
            $bind_names[] = $types;
            for ($i = 0; $i < count($params); $i++) {
                $bind_name = 'bind' . $i;
                $$bind_name = $params[$i];
                $bind_names[] = &$$bind_name;
            }
            call_user_func_array([$stmt, 'bind_param'], $bind_names);

            if (!$stmt->execute()) {
                $error = "Erreur lors de la mise à jour du profil: " . $stmt->error;
            }
            $stmt->close();
        }
    }

    // Update billing info if no error so far
    if (!$error) {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM dispatch_user_billing WHERE user_id=?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        $now = date('Y-m-d H:i:s');

        if ($count > 0) {
            $stmt = $conn->prepare("UPDATE dispatch_user_billing SET company_name=?, vat_number=?, company_number=?, tax_number=?, address=?, city=?, country=?, postcode=?, contact_email=?, contact_name=?, updated_at=? WHERE user_id=?");
            $stmt->bind_param('sssssssssssi', $company_name, $company_vat, $company_number, $tax_number, $company_address, $city, $country, $postcode, $contact_email, $contact_name, $now, $userId);
            if (!$stmt->execute()) {
                $error = "Erreur mise à jour facturation: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $stmt = $conn->prepare("INSERT INTO dispatch_user_billing (user_id, company_name, vat_number, company_number, tax_number, address, city, country, postcode, contact_email, contact_name, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('isssssssssss', $userId, $company_name, $company_vat, $company_number, $tax_number, $company_address, $city, $country, $postcode, $contact_email, $contact_name, $now);
            if (!$stmt->execute()) {
                $error = "Erreur insertion facturation: " . $stmt->error;
            }
            $stmt->close();
        }
    }

    if (!$error) {
        $success = "Profil mis à jour avec succès.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
        exit;
    }
}

// Reload user and billing data for display
$user = fetchUser($conn, $userId);
$billing = fetchBilling($conn, $userId);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Paramètres du profil</title>
    <link rel="stylesheet" href="/dispatch/shared/assets/css/styles.css" />
</head>
<body>
<?php include __DIR__ . '/header.php'; 
require_once __DIR__ . '/head.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/header.php';?>
<main>
    <h1>Paramètres du profil</h1>

    <?php if (!empty($_GET['success'])): ?>
        <p style="color:green; font-weight:bold;">Profil mis à jour avec succès.</p>
    <?php elseif ($error): ?>
        <p style="color:red; font-weight:bold;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" autocomplete="off">

        <fieldset>
            <legend>Informations générales</legend>

            <label for="salutation">Appellation</label>
            <select name="salutation" id="salutation">
                <option value="mr" <?= ($user['salutation'] === 'mr') ? 'selected' : '' ?>>Mr.</option>
                <option value="mrs" <?= ($user['salutation'] === 'mrs') ? 'selected' : '' ?>>Mme</option>
                <option value="ms" <?= ($user['salutation'] === 'ms') ? 'selected' : '' ?>>Mlle</option>
            </select>

            <label for="first_name">Prénom</label>
            <input type="text" name="first_name" id="first_name" value="<?= htmlspecialchars($user['first_name'] ?? '') ?>" required />

            <label for="last_name">Nom</label>
            <input type="text" name="last_name" id="last_name" value="<?= htmlspecialchars($user['last_name'] ?? '') ?>" required />

            <label for="gender">Genre</label>
            <select name="gender" id="gender">
                <option value="male" <?= ($user['gender'] === 'male') ? 'selected' : '' ?>>Homme</option>
                <option value="female" <?= ($user['gender'] === 'female') ? 'selected' : '' ?>>Femme</option>
                <option value="other" <?= ($user['gender'] === 'other') ? 'selected' : '' ?>>Autre</option>
            </select>

            <label for="ui_language">Langue de l'interface</label>
            <select name="ui_language" id="ui_language">
                <option value="fr" <?= ($user['ui_language'] === 'fr') ? 'selected' : '' ?>>Français</option>
                <option value="en" <?= ($user['ui_language'] === 'en') ? 'selected' : '' ?>>Anglais</option>
                <option value="de" <?= ($user['ui_language'] === 'de') ? 'selected' : '' ?>>Allemand</option>
            </select>

            <label for="currency">Devise</label>
            <select name="currency" id="currency">
                <option value="eur" <?= ($user['currency'] === 'eur') ? 'selected' : '' ?>>Euro (€)</option>
                <option value="usd" <?= ($user['currency'] === 'usd') ? 'selected' : '' ?>>Dollar ($)</option>
                <option value="tnd" <?= ($user['currency'] === 'tnd') ? 'selected' : '' ?>>Dinar tunisien (DT)</option>
            </select>

            <label for="email_alt">Email alternatif</label>
            <input type="email" name="email_alt" id="email_alt" value="<?= htmlspecialchars($user['email_alt'] ?? '') ?>" />

            <label for="company_name">Nom de la société</label>
            <input type="text" name="company_name" id="company_name" value="<?= htmlspecialchars($user['company_name'] ?? '') ?>" />

            <!-- *** Added new fields here *** -->

            <label for="phone_primary">Téléphone principal</label>
            <input type="text" name="phone_primary" id="phone_primary" value="<?= htmlspecialchars($user['phone_primary'] ?? '') ?>" />

            <label for="phone_secondary">Téléphone secondaire</label>
            <input type="text" name="phone_secondary" id="phone_secondary" value="<?= htmlspecialchars($user['phone_secondary'] ?? '') ?>" />

            <label for="site_title">Titre du site</label>
            <input type="text" name="site_title" id="site_title" value="<?= htmlspecialchars($user['site_title'] ?? '') ?>" />

        </fieldset>

        <fieldset>
            <legend>Changer le mot de passe</legend>
            <label for="password">Nouveau mot de passe (laisser vide pour ne pas changer)</label>
            <input type="password" name="password" id="password" autocomplete="new-password" />
        </fieldset>

        <fieldset>
            <legend>Photo de profil</legend>
            <?php if (!empty($user['photo_path'])): ?>
                <img src="/<?= htmlspecialchars($user['photo_path']) ?>" alt="Photo de profil" style="max-width:150px; max-height:150px;" />
            <?php endif; ?>
            <input type="file" name="photo" accept="image/*" />
        </fieldset>

        <fieldset>
            <legend>Informations de facturation</legend>

            <label for="company_vat">Numéro de TVA</label>
            <input type="text" name="company_vat" id="company_vat" value="<?= htmlspecialchars($billing['vat_number'] ?? '') ?>" />

            <label for="company_number">Numéro de société</label>
            <input type="text" name="company_number" id="company_number" value="<?= htmlspecialchars($billing['company_number'] ?? '') ?>" />

            <label for="tax_number">Numéro fiscal</label>
            <input type="text" name="tax_number" id="tax_number" value="<?= htmlspecialchars($billing['tax_number'] ?? '') ?>" />

            <label for="company_address">Adresse</label>
            <input type="text" name="company_address" id="company_address" value="<?= htmlspecialchars($billing['address'] ?? '') ?>" />

            <label for="city">Ville</label>
            <input type="text" name="city" id="city" value="<?= htmlspecialchars($billing['city'] ?? '') ?>" />

            <label for="country">Pays</label>
            <input type="text" name="country" id="country" value="<?= htmlspecialchars($billing['country'] ?? '') ?>" />

            <label for="postcode">Code postal</label>
            <input type="text" name="postcode" id="postcode" value="<?= htmlspecialchars($billing['postcode'] ?? '') ?>" />

            <label for="contact_email">Email contact</label>
            <input type="email" name="contact_email" id="contact_email" value="<?= htmlspecialchars($billing['contact_email'] ?? '') ?>" />

            <label for="contact_name">Nom contact</label>
            <input type="text" name="contact_name" id="contact_name" value="<?= htmlspecialchars($billing['contact_name'] ?? '') ?>" />
        </fieldset>

        <button type="submit">Enregistrer les modifications</button>
    </form>

</main>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>
