<?php $isAuthPage = $isAuthPage ?? false; ?>
<?php if (!$isAuthPage): ?>
<div id="page-wrapper" class="">

    <header id="main-header" class="header-container">
        <div class="logo-container">
            <a href="/dispatch/driver/dashboard.php">
                <img src="/dispatch/shared/assets/images/logo.png" alt="BrusselRide Logo" class="header-logo">
            </a>
        </div>

        <div class="header-right">
            <!-- Sidebar toggle button for mobile -->
            <button class="toggle-sidebar-btn" aria-label="Toggle sidebar" aria-expanded="false" aria-controls="sidebar">☰</button>

            <div class="lang-switcher">
                <select name="lang" id="langSelect" aria-label="Select language">
                    <option value="fr">Fr</option>
                    <option value="en">En</option>
                </select>
            </div>

            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" id="settingsDropdown" aria-haspopup="true" aria-expanded="false" type="button">
                    Mon Profil
                </button>
                <div class="dropdown-menu" id="settingsMenu" aria-labelledby="settingsDropdown">
                    <a class="dropdown-item" href="/dispatch/shared/inc/settings.php">Paramètres</a>
                    <a class="dropdown-item" href="/dispatch/driver/logout.php">Se déconnecter</a>
                </div>
            </div>

            <div class="notif-container" style="position: relative;">
                <button id="notifBell" class="notif-bell" title="Notifications" aria-haspopup="true" aria-expanded="false" aria-label="Notifications">
                    🔔 <span id="notifCount" class="notif-count" style="display: none;">0</span>
                </button>
                <ul id="notifDropdown" class="notif-dropdown" aria-label="Notification List" role="menu">
                    <!-- Notifications will load here -->
                </ul>
            </div>
        </div>
    </header>

    <?php require_once __DIR__ . '/subheader.php'; ?>

    <link rel="stylesheet" href="/dispatch/shared/assets/css/header.css">
    <script src="/dispatch/shared/assets/js/header.js" defer></script>

    <main id="main-content">
<?php endif; ?>
