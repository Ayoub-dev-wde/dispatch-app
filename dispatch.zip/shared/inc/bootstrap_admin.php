<?php
// inc/layout.php (or bootstrap.php)

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/admin/head.php';
require_once __DIR__ . '/admin/sidebar.php';
require_once __DIR__ . '/admin/header.php';

// Note: subheader.php is usually included only when you want a page-specific subheader
// so don't require it here globally unless *every* page uses it.
?>
