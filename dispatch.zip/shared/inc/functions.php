<?php
function get_page_title_and_breadcrumbs() {
    $title = "Dashboard";  // default title
    $breadcrumbs = [];
    $showBackButton = false;

    // Detect current page, e.g. by filename or query params
    $currentPage = basename($_SERVER['PHP_SELF']);

    switch ($currentPage) {
        case 'index.php':
            $title = "Réservations";
            break;

        case 'details.php':
            // Example: get trip ID from URL
            $tripId = isset($_GET['id']) ? intval($_GET['id']) : null;
            if ($tripId) {
                $title = "Réservations > $tripId Voir plus";
                $breadcrumbs = [
                    ['label' => 'Réservations', 'url' => 'index.php'],
                    ['label' => $tripId],
                ];
                $showBackButton = true;
            } else {
                $title = "Détails du trajet";
            }
            break;

        case 'edit.php':
            $tripId = isset($_GET['id']) ? intval($_GET['id']) : null;
            if ($tripId) {
                $title = "Réservations > $tripId Modifier";
                $breadcrumbs = [
                    ['label' => 'Réservations', 'url' => 'index.php'],
                    ['label' => $tripId],
                ];
                $showBackButton = true;
            } else {
                $title = "Modifier le trajet";
            }
            break;

        // Add more pages here as needed

        default:
            $title = ucfirst(str_replace('.php', '', $currentPage));
            break;
    }

    return [
        'title' => $title,
        'breadcrumbs' => $breadcrumbs,
        'showBackButton' => $showBackButton,
    ];
}
?>