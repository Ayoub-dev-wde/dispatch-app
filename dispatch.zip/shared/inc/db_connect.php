<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();  // Start session only if none is active
}

// Database configuration
$servername = "127.0.0.1";
$username   = "u570887711_U1BXM";
$password   = "g9bk9eCNle";
$dbname     = "u570887711_3W3db";

// Create mysqli connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Set UTF-8 charset
$conn->set_charset("utf8");
?>
