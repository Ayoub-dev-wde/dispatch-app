<?php
// dispatch/shared/inc/driver_utils.php

// Function to set and display session messages
function display_session_messages() {
    if (!empty($_SESSION['success'])) {
        echo '<div class="alert alert-success">' . esc_html($_SESSION['success']) . '</div>';
        unset($_SESSION['success']);
    }
    if (!empty($_SESSION['error'])) {
        echo '<div class="alert alert-danger">' . esc_html($_SESSION['error']) . '</div>';
        unset($_SESSION['error']);
    }
}

// Function to format date and time
function format_trip_datetime($datetime_str) {
    if (empty($datetime_str)) {
        return '-';
    }
    $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime_str);
    if (!$dt) {
        $dt = DateTime::createFromFormat('Y-m-d', $datetime_str);
    }
    return $dt ? $dt->format('d/m/Y H:i') : '-';
}

// Basic authorization check
function check_driver_session() {
    if (empty($_SESSION['driver_id'])) {
        $_SESSION['error'] = 'Veuillez vous connecter pour accéder à cette page.';
        // Make sure this path is correct for your login page
        header("Location: /dispatch/driver/login.php");
        exit;
    }
    return intval($_SESSION['driver_id']);
}
?>