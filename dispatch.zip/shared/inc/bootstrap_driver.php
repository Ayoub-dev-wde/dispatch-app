<?php
// dispatch/shared/inc/bootstrap_driver.php

// Ensure session is started very early
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db_connect.php'; // Your database connection
require_once __DIR__ . '/driver_utils.php'; // New file for helper functions

require_once __DIR__ . '/driver/head.php';    // Assumed to contain <head> tag and start <body>
require_once __DIR__ . '/driver/sidebar.php'; // Assumed to contain sidebar navigation
require_once __DIR__ . '/driver/header.php';  // Assumed to contain main header/navbar

// IMPORTANT: This file should probably also require wp-load.php
// But given your structure, you might be loading it directly in each page.
// If wp-load.php is not loaded by the driver/head.php or driver/header.php,
// it MUST be loaded at the top of each individual trip page.
?>