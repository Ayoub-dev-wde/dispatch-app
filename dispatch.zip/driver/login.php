<?php
ob_start();
session_start();
$pageTitle = "Connexion Chauffeur";
require_once __DIR__ . '/../shared/inc/bootstrap_driver.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $conn->prepare("SELECT id, name, password FROM drivers WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $driver = $result->fetch_assoc();
        $stmt->close();

        if ($driver && password_verify($password, $driver['password'])) {
            $_SESSION['driver_id'] = $driver['id'];
            $_SESSION['driver_name'] = $driver['name'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Identifiants incorrects. Veuillez réessayer.";
        }
    } else {
        $error = "Veuillez remplir tous les champs.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $pageTitle ?> | DigitalEyes</title>
    <link href="/dispatch/shared/assets/css/styles.css" rel="stylesheet">
</head>
<body class="login-page">
    <div class="login-container">
        <h1>🚖 Connexion Chauffeur</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post" class="login-form">
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" required autofocus>
            </div>

            <div class="form-group">
                <label>Mot de passe:</label>
                <input type="password" name="password" required>
            </div>

            <button class="btn btn-primary" type="submit">🔐 Se connecter</button>
        </form>

        <p class="back-link"><a href="/dispatch/index.php">← Retour à l'accueil</a></p>
    </div>
</body>
</html>

<?php ob_end_flush(); ?>
