<h2>Votre inscription a été soumise !</h2>
<p>Nous vous contacterons après la vérification de vos informations.</p>
<p class="back-link"><a href="/dispatch/index.php">← Retour à l'accueil</a></p>
