<?php
// Top logic (you already have this)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ob_start();
session_start();
require_once __DIR__ . '/../shared/inc/db_connect.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['register_driver'] = [
        'name' => trim($_POST['name']),
        'phone' => trim($_POST['phone']),
        'email' => trim($_POST['email']),
        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
        'whatsapp' => trim($_POST['whatsapp']),
        'gender' => $_POST['gender'] ?? null,
        'language' => $_POST['language'] ?? 'Français',
        'license_info' => trim($_POST['license_info']),
        'license_expires' => $_POST['license_expires'],
        'pco_license' => trim($_POST['pco_license']),
        'pco_license_expires' => $_POST['pco_license_expires'],
        'comment' => trim($_POST['comment']),
        'photo' => null,
    ];

    if (!empty($_FILES['photo']['name'])) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('driver_', true) . '.' . $ext;
        $destination = __DIR__ . '/../uploads/admin/drivers/' . $filename;
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
            $_SESSION['register_driver']['photo'] = $filename;
        }
    }

    // Basic validation
    if (empty($_SESSION['register_driver']['name']) || empty($_SESSION['register_driver']['phone']) ||
        empty($_SESSION['register_driver']['email']) || empty($_POST['password']) ||
        empty($_SESSION['register_driver']['license_expires'])) {
        $errors[] = "Veuillez remplir tous les champs obligatoires.";
    }

    if (empty($errors)) {
        header("Location: register_vehicle.php");
        exit();
    }
}
?>

<!-- Driver form HTML -->
<h2>Étape 1 : Informations du chauffeur</h2>

<?php if (!empty($errors)): ?>
    <div class="errors"><?= implode('<br>', $errors); ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <input name="name" placeholder="Nom complet" required>
    <input name="phone" placeholder="Téléphone" required>
    <input name="email" type="email" placeholder="Email" required>
    <input name="password" type="password" placeholder="Mot de passe" required>
    <input name="whatsapp" placeholder="WhatsApp">
    <select name="gender">
        <option value="Homme">Homme</option>
        <option value="Femme">Femme</option>
    </select>
    <input name="language" value="Français" hidden>
    <input name="license_info" placeholder="Permis de conduire">
    <input name="license_expires" type="date">
    <input name="pco_license" placeholder="Licence PCO">
    <input name="pco_license_expires" type="date">
    <textarea name="comment" placeholder="Commentaire..."></textarea>
    <input type="file" name="photo" accept="image/*">
    <button type="submit">Suivant</button>
</form>
