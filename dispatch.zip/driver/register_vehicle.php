<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ob_start();
session_start();
require_once __DIR__ . '/../shared/inc/db_connect.php';

if (!isset($_SESSION['register_driver'])) {
    header("Location: register.php");
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $make = $_POST['make'] ?? '';
    $model = $_POST['model'] ?? '';
    $year = $_POST['year'] ?? '';
    $license_plate = $_POST['license_plate'] ?? '';
    $color = $_POST['color'] ?? '';
    $comment = $_POST['comment'] ?? '';
    $status = 'en_attente';
    $photo = null;

    // Upload vehicle photo
    if (!empty($_FILES['photo']['name'])) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('vehicle_', true) . '.' . $ext;
        $destination = __DIR__ . '/../uploads/admin/vehicles/' . $filename;
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
            $photo = 'uploads/admin/vehicles/' . $filename;
        }
    }

    // Insert vehicle
    $stmt = $conn->prepare("INSERT INTO vehicles (make, model, year, license_plate, status, color, comment, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisssss", $make, $model, $year, $license_plate, $status, $color, $comment, $photo);
    if (!$stmt->execute()) {
        die("Erreur lors de l'insertion du véhicule : " . $stmt->error);
    }
    $vehicle_id = $conn->insert_id;
    $stmt->close();

    // Insert driver
    $d = $_SESSION['register_driver'];
    $stmt = $conn->prepare("INSERT INTO drivers (name, phone, email, whatsapp, gender, language, vehicle_id, license_info, license_expires, pco_license, pco_license_expires, comment, photo_id, password, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'en_attente', NOW())");
    $stmt->bind_param("ssssssisssssss", $d['name'], $d['phone'], $d['email'], $d['whatsapp'], $d['gender'], $d['language'], $vehicle_id, $d['license_info'], $d['license_expires'], $d['pco_license'], $d['pco_license_expires'], $d['comment'], $d['photo'], $d['password']);
    if (!$stmt->execute()) {
        die("Erreur lors de l'insertion du chauffeur : " . $stmt->error);
    }
    $stmt->close();

    unset($_SESSION['register_driver']);
    header("Location: success.php");
    exit();
}
?>

<!-- Vehicle Form HTML -->
<h2>Étape 2 : Informations du véhicule</h2>
<form method="POST" enctype="multipart/form-data">
    <input name="make" placeholder="Marque" required>
    <input name="model" placeholder="Modèle" required>
    <input name="year" type="number" placeholder="Année" required>
    <input name="license_plate" placeholder="Immatriculation" required>
    <input name="color" placeholder="Couleur">
    <textarea name="comment" placeholder="Commentaire..."></textarea>
    <input type="file" name="photo" accept="image/*">
    <button type="submit">Soumettre</button>
</form>
