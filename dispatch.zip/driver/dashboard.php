<?php
ob_start();
require_once __DIR__ . '/../shared/inc/bootstrap_driver.php';

$pageTitle = "Tableau de bord";
$breadcrumbs = [
    ['label' => 'Accueil']
];
?>


<div class="dashboard-container">
    <h2>Bienvenue, <?= htmlspecialchars($_SESSION['driver']['name'] ?? 'Chauffeur') ?> 👋</h2>

    <div class="dashboard-stats">
        <div class="stat-card">
            <i class="fas fa-route"></i>
            <div>
                <h3>12</h3>
                <p>Courses du mois</p>
            </div>
        </div>
        <div class="stat-card">
            <i class="fas fa-clock"></i>
            <div>
                <h3>34h</h3>
                <p>Temps de conduite</p>
            </div>
        </div>
        <div class="stat-card">
            <i class="fas fa-star"></i>
            <div>
                <h3>4.8</h3>
                <p>Note moyenne</p>
            </div>
        </div>
    </div>

    <div class="dashboard-section">
        <h3>Prochaine course</h3>
        <p>Course prévue pour aujourd’hui à 15:00 vers Aéroport Zaventem.</p>
    </div>
</div>

<style>
    .dashboard-container {
        padding: 1.5rem;
    }

    .dashboard-stats {
        display: flex;
        gap: 1.5rem;
        margin: 1.5rem 0;
        flex-wrap: wrap;
    }

    .stat-card {
        flex: 1 1 200px;
        background: #f7f7f7;
        border-radius: 8px;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .stat-card i {
        font-size: 2rem;
        color: #3366cc;
    }

    .stat-card h3 {
        margin: 0;
        font-size: 1.5rem;
    }

    .dashboard-section {
        margin-top: 2rem;
    }
</style>

<?php require_once __DIR__ . '/../../shared/inc/driver/footer.php'; ?>
<?php ob_end_flush(); ?>
