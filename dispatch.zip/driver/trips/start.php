<?php
ob_start();
require_once dirname(__DIR__, 2) . '/../wp-load.php';
require_once __DIR__ . '/../../shared/inc/bootstrap_driver.php';



if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ./index.php");
    exit();
}

$trip_id = (int) $_GET['id'];
$driver_id = $_SESSION['driver_id'] ?? null;

if (!$driver_id) {
    $_SESSION['error'] = "Session expirée. Veuillez vous reconnecter.";
    header("Location: /../../login.php");
    exit();
}

// Vérifie que la course appartient bien au chauffeur
$assigned_driver = (int) get_post_meta($trip_id, 'driver_id', true);
if ($assigned_driver !== (int) $driver_id) {
    $_SESSION['error'] = "Vous n'êtes pas autorisé à démarrer cette course.";
    header("Location: ./index.php");
    exit();
}

// Vérifie que la course est dans un état valide
$current_status = get_post_meta($trip_id, 'trip_status', true);
if ($current_status !== 'accepted') {
    $_SESSION['error'] = "Impossible de démarrer cette course. Statut actuel : $current_status.";
    header("Location: ./index.php");
    exit();
}

// Met à jour le statut de la course
update_post_meta($trip_id, 'trip_status', 'processing');
$_SESSION['success'] = "Course démarrée avec succès.";
header("Location: ./index.php");
exit();

ob_end_flush();
