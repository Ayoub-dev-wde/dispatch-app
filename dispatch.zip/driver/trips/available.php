<?php
ob_start();
require_once dirname(__DIR__, 2) . '/../wp-load.php';
require_once __DIR__ . '/../../shared/inc/bootstrap_driver.php';

$pageTitle = "Toutes les Courses";
$breadcrumbs = [
    ['label' => 'Tableau de Bord', 'url' => '/dispatch/driver/dashboard.php'],
    ['label' => 'Toutes les Courses']
];

// Handle filtering
$filter = $_GET['filter'] ?? 'all'; // all, available, dispatched

// Pagination
$paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$posts_per_page = 10;

// Base query
$meta_query = [];

if ($filter === 'available') {
    $meta_query[] = [
        'key'     => 'driver_id',
        'compare' => 'NOT EXISTS',
    ];
} elseif ($filter === 'dispatched') {
    $meta_query[] = [
        'key'     => 'driver_id',
        'compare' => 'EXISTS',
    ];
}

$query = new WP_Query([
    'post_type'      => 'mptbm_booking',
    'posts_per_page' => $posts_per_page,
    'paged'          => $paged,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'meta_query'     => $meta_query,
]);
?>

<div class="container">
    <h2 class="mb-3"><?= esc_html($pageTitle) ?></h2>

    <!-- Session Messages -->
    <?php if (!empty($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= esc_html($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= esc_html($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Filter Options -->
    <form method="get" class="mb-4">
        <div class="row g-2">
            <div class="col-auto">
                <select name="filter" class="form-select" onchange="this.form.submit()">
                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Toutes les courses</option>
                    <option value="available" <?= $filter === 'available' ? 'selected' : '' ?>>Disponibles</option>
                    <option value="dispatched" <?= $filter === 'dispatched' ? 'selected' : '' ?>>Déjà dispatchées</option>
                </select>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Course #</th>
                <th>Départ</th>
                <th>Destination</th>
                <th>Date</th>
                <th>État</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($query->have_posts()): ?>
                <?php while ($query->have_posts()): $query->the_post();
                    $post_id      = get_the_ID();
                    $order_number = get_post_meta($post_id, 'mptbm_order_id', true) ?: 'N/A';
                    $pickup       = get_post_meta($post_id, 'mptbm_start_place', true) ?: '-';
                    $destination  = get_post_meta($post_id, 'mptbm_end_place', true) ?: '-';
                    $datetime     = get_post_meta($post_id, 'mptbm_date', true);
                    $driver_id    = get_post_meta($post_id, 'driver_id', true);
                    $trip_status  = get_post_meta($post_id, 'trip_status', true) ?: 'pending';
                    $is_available = empty($driver_id);

                    $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime)
                        ?: DateTime::createFromFormat('Y-m-d', $datetime);
                    $formatted_date = $dt ? $dt->format('d/m/Y H:i') : '-';

                    $status_label = match ($trip_status) {
                        'pending'    => '<span class="badge bg-warning text-dark">En attente</span>',
                        'accepted'   => '<span class="badge bg-primary">Acceptée</span>',
                        'processing' => '<span class="badge bg-info text-dark">En cours</span>',
                        'completed'  => '<span class="badge bg-success">Terminée</span>',
                        'cancelled'  => '<span class="badge bg-danger">Annulée</span>',
                        default      => '<span class="badge bg-secondary">Inconnue</span>',
                    };
                ?>
                <tr class="<?= $is_available ? '' : 'table-secondary text-muted' ?>">
                    <td><?= esc_html($order_number) ?></td>
                    <td><?= esc_html($pickup) ?></td>
                    <td><?= esc_html($destination) ?></td>
                    <td><?= esc_html($formatted_date) ?></td>
                    <td>
                        <?= $is_available
                            ? '<span class="badge bg-success">Disponible</span>'
                            : '<span class="badge bg-secondary">Déjà dispatchée</span>' ?>
                        <?= ' ' . $status_label ?>
                    </td>
                    <td>
                        <a href="details.php?id=<?= urlencode($post_id) ?>" class="btn btn-sm btn-info">Voir</a>
                        <?php if ($is_available): ?>
                            <a href="allocate.php?id=<?= urlencode($post_id) ?>" class="btn btn-sm btn-primary">Prendre</a>
                        <?php else: ?>
                            <button class="btn btn-sm btn-secondary" disabled>Indisponible</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            <?php else: ?>
                <tr><td colspan="6">Aucune course trouvée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php
    $total_pages = $query->max_num_pages;
    if ($total_pages > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php
                echo paginate_links([
                    'base'      => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                    'format'    => '?paged=%#%' . ($filter !== 'all' ? '&filter=' . urlencode($filter) : ''),
                    'current'   => $paged,
                    'total'     => $total_pages,
                    'mid_size'  => 2,
                    'prev_text' => __('&laquo; Précédent', 'textdomain'),
                    'next_text' => __('Suivant &raquo;', 'textdomain'),
                    'type'      => 'list',
                ]);
                ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php ob_end_flush(); ?>
