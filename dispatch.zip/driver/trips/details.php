<?php
// Charger WordPress si ce n'est pas déjà fait
if (!function_exists('get_post_meta')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

// Connexion directe à la base pour la table "drivers"
global $wpdb;
$drivers_table = 'drivers'; // Table sans préfixe wp_

// Valider le paramètre id
$postID = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($postID <= 0 || get_post_type($postID) !== 'mptbm_booking') {
    wp_die('Trajet invalide.');
}

// Setup interface
$orderNumber = get_post_meta($postID, 'mptbm_order_id', true) ?: 'Inconnu';
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Réservations', 'url' => 'index.php'],
    ['label' => 'Détails du trajet n°' . esc_html($orderNumber)]
];
$showBackButton = true;
$isSubPage = true;

require_once __DIR__ . '/../../shared/inc/bootstrap_driver.php';

// Métadonnées du trajet
$meta = fn(string $k) => get_post_meta($postID, $k, true);

$billingName    = $meta('mptbm_billing_name');
$phone          = $meta('mptbm_billing_phone');
$email          = $meta('mptbm_billing_email');
$pickup         = $meta('mptbm_start_place');
$destination    = $meta('mptbm_end_place');
$datetime       = $meta('mptbm_date');
$transferType   = $meta('mptbm_taxi_return');
$vehicleID      = $meta('mptbm_id');
$vehicleTitle   = $vehicleID ? get_the_title($vehicleID) : '-';
$basePrice      = $meta('mptbm_base_price')     ?: '-';
$paymentMethod  = $meta('mptbm_payment_method') ?: '-';
$orderStatus    = $meta('mptbm_order_status')   ?: '-';

// Récupérer les infos du chauffeur
$driverID = $meta('driver_id');
$dispatchStatus = 'Non dispatchée';
$driverInfo = null;

if ($driverID) {
    $driverInfo = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$drivers_table} WHERE id = %d", $driverID)
    );
    if ($driverInfo) {
        $dispatchStatus = 'Dispatchée';
    }
}

// Analyse date/heure
$tripDate = $pickupTime = '';
if ($datetime) {
    $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime)
        ?: DateTime::createFromFormat('Y-m-d', $datetime);
    if ($dt) {
        $tripDate   = $dt->format('Y-m-d');
        $pickupTime = $dt->format('H:i');
    }
}

$transferLabel = $transferType === '2' ? 'Aller-retour'
              : ($transferType === '1' ? 'Aller' : htmlspecialchars($transferType));

// URL de la photo du chauffeur (si existe)
$driverPhoto = $driverInfo && $driverInfo->photo_id
    ? '/uploads/admin/' . esc_attr($driverInfo->photo_id)
    : '/dispatch/shared/assets/img/default-profile.png';
?>

<!-- ---------- CONTENU DE LA PAGE ---------- -->
<div class="trip-details">
    <h2 class="trip-details__title"><?= esc_html($pageTitle) ?></h2>

    <table class="trip-details__table">
        <tbody>
            <tr><th>Trip n°</th>        <td><?= esc_html($orderNumber) ?></td></tr>
            <tr><th>Client</th>         <td><?= esc_html($billingName) ?></td></tr>
            <tr><th>Téléphone</th>      <td><?= esc_html($phone) ?></td></tr>
            <tr><th>Email</th>          <td><?= esc_html($email) ?></td></tr>
            <tr><th>Pickup</th>         <td><?= esc_html($pickup) ?></td></tr>
            <tr><th>Destination</th>    <td><?= esc_html($destination) ?></td></tr>
            <tr><th>Date</th>           <td><?= esc_html($tripDate) ?></td></tr>
            <tr><th>Heure</th>          <td><?= esc_html($pickupTime) ?></td></tr>
            <tr><th>Type</th>           <td><?= esc_html($transferLabel) ?></td></tr>
            <tr><th>Véhicule</th>       <td><?= esc_html($vehicleTitle) ?></td></tr>
            <tr><th>Prix (€)</th>       <td><?= esc_html($basePrice) ?></td></tr>
            <tr><th>Paiement</th>       <td><?= esc_html($paymentMethod) ?></td></tr>
            <tr><th>Statut</th>         <td><?= esc_html($orderStatus) ?></td></tr>
            <tr><th>Statut course</th>  <td><?= esc_html($dispatchStatus) ?></td></tr>
        </tbody>
    </table>

    <?php if ($driverInfo): ?>
    <h3>Informations du chauffeur</h3>
    <div class="driver-details">
        <img src="<?= esc_url($driverPhoto) ?>" alt="Photo chauffeur" width="100" style="border-radius: 50px;">
        <table>
            <tr><th>Nom</th>              <td><?= esc_html($driverInfo->name) ?></td></tr>
            <tr><th>Email</th>            <td><?= esc_html($driverInfo->email) ?></td></tr>
            <tr><th>Téléphone</th>        <td><?= esc_html($driverInfo->phone) ?></td></tr>
            <tr><th>Status</th>           <td><?= esc_html($driverInfo->status) ?></td></tr>
            <tr><th>Genre</th>            <td><?= esc_html($driverInfo->gender) ?></td></tr>
            <tr><th>Langue</th>           <td><?= esc_html($driverInfo->language) ?></td></tr>
            <tr><th>Whatsapp</th>         <td><?= esc_html($driverInfo->whatsapp) ?></td></tr>
            <tr><th>Licence</th>          <td><?= esc_html($driverInfo->license_info) ?></td></tr>
            <tr><th>Expiration Licence</th><td><?= esc_html($driverInfo->license_expires) ?></td></tr>
            <tr><th>PCO Licence</th>      <td><?= esc_html($driverInfo->pco_license) ?></td></tr>
            <tr><th>Expiration PCO</th>   <td><?= esc_html($driverInfo->pco_license_expires) ?></td></tr>
            <tr><th>Commentaire</th>      <td><?= esc_html($driverInfo->comment) ?></td></tr>
        </table>
    </div>
    <?php else: ?>
        <p>Chauffeur non assigné ou introuvable.</p>
    <?php endif; ?>

    <p class="trip-details__back">
        <a href="available.php">← Retour à la liste des trajets</a>
    </p>
</div>

<link rel="stylesheet" href="/dispatch/shared/assets/css/trip-details.css">
