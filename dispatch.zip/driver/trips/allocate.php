<?php
ob_start();
require_once dirname(__DIR__, 2) . '/../wp-load.php';
require_once __DIR__ . '/../../shared/inc/bootstrap_driver.php';

// Vérifier que le chauffeur est connecté
if (empty($_SESSION['driver_id'])) {
    header("Location: /dispatch/driver/login.php");
    exit;
}

$driver_id = intval($_SESSION['driver_id']);
$trip_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Valider la course
if ($trip_id <= 0 || get_post_type($trip_id) !== 'mptbm_booking') {
    $_SESSION['error'] = "Course invalide.";
    header("Location: available.php");
    exit;
}

// Vérifie si la course est déjà assignée
$already_assigned = get_post_meta($trip_id, 'driver_id', true);
if (!empty($already_assigned)) {
    $_SESSION['error'] = "Cette course est déjà dispatchée.";
    header("Location: available.php");
    exit;
}

// Récupérer le nom du chauffeur
$driver = get_userdata($driver_id);
$driver_name = $driver ? $driver->display_name : '';

// Assigner les métadonnées
update_post_meta($trip_id, 'driver_id', $driver_id);
update_post_meta($trip_id, 'mptbm_driver_name', $driver_name); // utile pour d'autres modules éventuels
update_post_meta($trip_id, 'trip_status', 'accepted');

// Redirection avec message
$_SESSION['success'] = "Course assignée avec succès.";
header("Location: index.php");
exit;
ob_end_flush();
