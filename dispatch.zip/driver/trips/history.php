<?php
require_once dirname(__DIR__, 2) . '/../wp-load.php';
require_once __DIR__ . '/../../shared/inc/bootstrap_driver.php';

$pageTitle = "Historique des Courses";
$breadcrumbs = [
    ['label' => 'Tableau de Bord', 'url' => '/dispatch/driver/dashboard.php'],
    ['label' => 'Historique des Courses']
];

// Vérifie que le chauffeur est connecté
$currentDriverId = $_SESSION['driver_id'] ?? 0;
if (!$currentDriverId) {
    header("Location: /dispatch/driver/login.php");
    exit;
}

// Requête pour récupérer les courses terminées
$query = new WP_Query([
    'post_type' => 'mptbm_booking',
    'posts_per_page' => -1,
    'meta_query' => [
        'relation' => 'AND',
        [
            'key'     => 'driver_id',
            'value'   => $currentDriverId,
            'compare' => '='
        ],
        [
            'key'     => 'trip_status',
            'value'   => 'completed',
            'compare' => '='
        ]
    ],
    'orderby' => 'date',
    'order' => 'DESC',
]);
?>

<div class="container">
    <h2 class="mb-3"><?= htmlspecialchars($pageTitle) ?></h2>

    <!-- Messages session -->
    <?php if (!empty($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= esc_html($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= esc_html($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Course #</th>
                <th>Départ</th>
                <th>Destination</th>
                <th>Date</th>
                <th>Statut Paiement</th>
                <th>Statut Commande</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($query->have_posts()): ?>
                <?php while ($query->have_posts()): $query->the_post();
                    $post_id       = get_the_ID();
                    $order_number  = get_post_meta($post_id, 'mptbm_order_id', true) ?: 'N/A';
                    $pickup        = get_post_meta($post_id, 'mptbm_start_place', true) ?: '-';
                    $destination   = get_post_meta($post_id, 'mptbm_end_place', true) ?: '-';
                    $datetime      = get_post_meta($post_id, 'mptbm_date', true);
                    $order_status  = get_post_meta($post_id, 'mptbm_order_status', true) ?: 'failed';

                    $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime)
                        ?: DateTime::createFromFormat('Y-m-d', $datetime);
                    $formatted_date = $dt ? $dt->format('d/m/Y H:i') : '-';

                    $badge_class_payment = match ($order_status) {
                        'completed' => 'bg-success',
                        'failed'    => 'bg-danger',
                        default     => 'bg-secondary',
                    };
                ?>
                <tr>
                    <td><?= esc_html($order_number) ?></td>
                    <td><?= esc_html($pickup) ?></td>
                    <td><?= esc_html($destination) ?></td>
                    <td><?= esc_html($formatted_date) ?></td>
                    <td><span class="badge <?= $badge_class_payment ?>"><?= esc_html($order_status) ?></span></td>
                    <td><span class="badge bg-success">terminée</span></td>
                    <td>
                        <a href="details.php?id=<?= $post_id ?>" class="btn btn-sm btn-info">Voir</a>
                    </td>
                </tr>
                <?php endwhile; wp_reset_postdata(); ?>
            <?php else: ?>
                <tr><td colspan="7">Aucune course terminée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
