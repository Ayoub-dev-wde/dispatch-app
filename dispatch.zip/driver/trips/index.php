<?php
require_once dirname(__DIR__, 2) . '/../wp-load.php';
require_once __DIR__ . '/../../shared/inc/bootstrap_driver.php';

$pageTitle = "Mes Courses";
$breadcrumbs = [
    ['label' => 'Tableau de Bord', 'url' => '/dispatch/driver/dashboard.php'],
    ['label' => 'Mes Courses']
];

// Vérifie que le chauffeur est bien connecté
$currentDriverId = $_SESSION['driver_id'] ?? 0;
if (!$currentDriverId) {
    header("Location: /dispatch/driver/login.php");
    exit;
}

// Récupération des courses assignées à ce chauffeur
$query = new WP_Query([
    'post_type' => 'mptbm_booking',
    'posts_per_page' => -1,
    'meta_query' => [
        'relation' => 'AND',
        [
            'key' => 'driver_id',
            'value' => $currentDriverId,
            'compare' => '='
        ],
        [
            'key' => 'trip_status',
            'value' => 'completed',
            'compare' => '!='  // EXCLURE les courses terminées
        ]
    ],
    'orderby' => 'date',
    'order' => 'DESC',
]);


?>

<div class="container">
    <h2 class="mb-3"><?= htmlspecialchars($pageTitle) ?></h2>

    <!-- Messages de session -->
    <?php if (!empty($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Course #</th>
                <th>Départ</th>
                <th>Destination</th>
                <th>Date</th>
                <th>Statut de commande</th>
                <th>Statut de paiement</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($query->have_posts()): ?>
                <?php while ($query->have_posts()): $query->the_post();
                    $post_id       = get_the_ID();
                    $order_number  = get_post_meta($post_id, 'mptbm_order_id', true);
                    $pickup        = get_post_meta($post_id, 'mptbm_start_place', true);
                    $destination   = get_post_meta($post_id, 'mptbm_end_place', true);
                    $datetime      = get_post_meta($post_id, 'mptbm_date', true);
                    $order_status  = get_post_meta($post_id, 'mptbm_order_status', true) ?: 'failed';
                    $trip_status   = get_post_meta($post_id, 'trip_status', true) ?: 'en attente';

                    $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime)
                        ?: DateTime::createFromFormat('Y-m-d', $datetime);
                    $formatted_date = $dt ? $dt->format('d/m/Y H:i') : '-';

                    // Détermination classes CSS pour les statuts
                    $badge_class_payment = match ($order_status) {
                        'completed' => 'bg-success',
                        'failed'    => 'bg-danger',
                        default     => 'bg-secondary',
                    };
                    $badge_class_trip = match ($trip_status) {
    'accepted'  => 'bg-success',
    'processing'=> 'bg-warning',
    'completed' => 'bg-secondary',
    default     => 'bg-warning', // for 'en attente' during transition
                    };
                ?>
                <tr>
                    <td><?= esc_html($order_number) ?></td>
                    <td><?= esc_html($pickup) ?></td>
                    <td><?= esc_html($destination) ?></td>
                    <td><?= esc_html($formatted_date) ?></td>
                    <td><span class="badge <?= $badge_class_trip ?>"><?= esc_html($trip_status) ?></span></td>
                    <td><span class="badge <?= $badge_class_payment ?>"><?= esc_html($order_status) ?></span></td>
                    <td>
    <a href="details.php?id=<?= $post_id ?>" class="btn btn-sm btn-info">Voir</a>

    <?php if ($trip_status === 'accepted'): ?>
        <a href="start.php?id=<?= $post_id ?>" class="btn btn-sm btn-success ms-1">Démarrer la course</a>
    <?php else: ?>
        <button class="btn btn-sm btn-secondary ms-1" disabled>Démarrer la course</button>
    <?php endif; ?>

    <?php if ($trip_status === 'processing'): ?>
        <a href="complete.php?id=<?= $post_id ?>" class="btn btn-sm btn-warning ms-1">Terminer la course</a>
    <?php endif; ?>
</td>

                </tr>
                <?php endwhile; wp_reset_postdata(); ?>
            <?php else: ?>
                <tr><td colspan="7">Aucune course assignée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
