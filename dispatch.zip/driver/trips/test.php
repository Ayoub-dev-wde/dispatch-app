<?php
if (isset($_GET['create_test_trip'])) {
    $new_post = [
        'post_title'   => 'Course Test Acceptée',
        'post_status'  => 'publish',
        'post_type'    => 'mptbm_booking',
        'post_author'  => get_current_user_id(),
    ];

    $post_id = wp_insert_post($new_post);

    if ($post_id && !is_wp_error($post_id)) {
        update_post_meta($post_id, 'mptbm_order_id', 'TEST123');
        update_post_meta($post_id, 'mptbm_start_place', 'Paris');
        update_post_meta($post_id, 'mptbm_end_place', 'Lyon');
        update_post_meta($post_id, 'mptbm_date', '2025-06-01 10:00');
        update_post_meta($post_id, 'mptbm_payment_method', 'cash');
        update_post_meta($post_id, 'mptbm_transfer_type', 'oneway');
        update_post_meta($post_id, 'trip_status', 'accepté');

        $_SESSION['success'] = "Course de test créée avec succès.";
        header("Location: index.php");
        exit;
    } else {
        $_SESSION['error'] = "Échec de la création de la course.";
    }
}
