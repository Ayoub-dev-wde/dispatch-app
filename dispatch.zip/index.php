<?php
// dispatch/index.php
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dispatch - Portail d'accès</title>
    <link rel="stylesheet" href="shared/assets/css/styles.css">
    
</head>
<body>
    <div class="container py-5">
        <div class="text-center mb-4">
            <img src="shared/assets/images/logo.png" alt="DigitalEyes" style="height: 80px;">
            <h2 class="mt-3">Bienvenue sur la plateforme de dispatch</h2>
            <p class="text-muted">Choisissez votre espace de connexion</p>
        </div>
        <div class="row justify-content-center">
            <!-- Admin Login -->
            <div class="col-md-3">
                <div class="card login-card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Admin</h5>
                        <p class="card-text">Accès au tableau de bord admin</p>
                        <a href="admin/login.php" class="btn btn-primary">Connexion Admin</a>
                    </div>
                </div>
            </div>
            <!-- Driver Login -->
            <div class="col-md-3">
                <div class="card login-card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Chauffeur</h5>
                        <p class="card-text">Accès au tableau de bord chauffeur</p>
                        <a href="driver/login.php" class="btn btn-success">Connexion Chauffeur</a>
                        <li><a href="/dispatch/driver/register.php">Devenir un Chauffeur</a></li>
                    </div>
                </div>
            </div>
            <!-- Passenger Login (coming soon) -->
            <div class="col-md-3">
                <div class="card login-card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Passenger</h5>
                        <p class="card-text">Bientôt disponible</p>
                        <a href="passenger/login.php" class="btn btn-secondary disabled">Connexion Client</a>
                        <li><a href="/dispatch/passenger/register.php">Créer un compte passager</a></li>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
