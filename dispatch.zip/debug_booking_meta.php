<?php
require_once(dirname(__FILE__) . '/../wp-load.php');

// Query 1 booking to debug
$args = array(
    'post_type' => 'mptbm_booking',
    'posts_per_page' => 1,
    'post_status' => 'publish'
);
$orders = new WP_Query($args);

if ($orders->have_posts()) {
    while ($orders->have_posts()) {
        $orders->the_post();
        echo "<h2>Booking ID: " . get_the_ID() . "</h2>";

        $meta = get_post_meta(get_the_ID());
        echo "<pre>";
        print_r($meta);  // This will list ALL meta keys and values
        echo "</pre>";
    }
} else {
    echo "No bookings found.";
}
// In your plugin or theme's functions.php
add_action('admin_menu', 'add_booking_debug_page');

function add_booking_debug_page() {
    add_menu_page(
        'Booking Debug',          // Page title
        'Booking Debug',          // Menu title
        'manage_options',         // Capability required
        'booking-debug',          // Menu slug
        'display_booking_debug',  // Function to display the page
        'dashicons-search',       // Icon
        25                        // Position in the menu
    );
}

function display_booking_debug() {
    echo '<div class="wrap">';
    echo '<h1>Booking Debugging</h1>';
    
    // Insert the debugging code here
    $args = array(
        'post_type' => 'mptbm_booking',
        'posts_per_page' => 1,
        'post_status' => 'publish'
    );
    $orders = new WP_Query($args);

    if ($orders->have_posts()) {
        while ($orders->have_posts()) {
            $orders->the_post();
            echo "<h2>Booking ID: " . get_the_ID() . "</h2>";
            
            $meta = get_post_meta(get_the_ID());
            echo "<h3>Specific Meta Fields:</h3>";
            echo "<pre>";
            echo "Order ID: " . get_post_meta(get_the_ID(), 'wp_order_id', true) . "<br>";
            echo "Trip ID: " . get_post_meta(get_the_ID(), 'trip_id', true) . "<br>";
            echo "</pre>";

            echo "<h3>All Meta Data:</h3>";
            echo "<pre>";
            print_r($meta);
            echo "</pre>";
        }
    } else {
        echo "No bookings found.";
    }

    echo '</div>';
}

?>
