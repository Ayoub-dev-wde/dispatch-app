<?php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', true);

$pageTitle = "Tableau de bord";
$breadcrumbs = [];
$showBackButton = false;

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
require_once __DIR__ . '/../shared/inc/bootstrap_admin.php';

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord Passager</title>
</head>
<body>
    <h1>Bienvenue, <?= htmlspecialchars($_SESSION['passenger_name']) ?> !</h1>
    <p>Voici votre tableau de bord passager.</p>
    <a href="logout.php">Se déconnecter</a>
</body>
</html>
