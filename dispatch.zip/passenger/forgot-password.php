<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize_email($_POST['user_login']);

    if (empty($email)) {
        $message = "Veuillez entrer votre adresse e-mail.";
    } elseif (!is_email($email)) {
        $message = "Adresse e-mail invalide.";
    } else {
        $user = get_user_by('email', $email);
        if ($user) {
            // Send the password reset email using WP core
            $result = retrieve_password($user->user_login);
            if ($result === true) {
                $success = true;
                $message = "Si votre adresse e-mail est correcte, un lien de réinitialisation vous a été envoyé.";
            } else {
                $message = "Une erreur est survenue. Veuillez réessayer plus tard.";
            }
        } else {
            // Still show the same message for privacy
            $success = true;
            $message = "Si votre adresse e-mail est correcte, un lien de réinitialisation vous a été envoyé.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mot de passe oublié</title>
</head>
<body>
    <h2>Réinitialiser le mot de passe</h2>

    <?php if ($message): ?>
        <p style="color: <?= $success ? 'green' : 'red' ?>;"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="user_login">Adresse e-mail</label><br>
        <input type="email" name="user_login" id="user_login" required><br><br>
        <button type="submit">Envoyer le lien de réinitialisation</button>
    </form>

    <p><a href="login.php">← Retour à la connexion</a></p>
</body>
</html>
