<?php
session_start();
require_once __DIR__ . '/../shared/inc/db_connect.php';
require_once __DIR__ . '/../shared/inc/wp_password_verify.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if ($email && $password) {
        $stmt = $conn->prepare("SELECT ID, user_email, user_pass, display_name FROM wp_users WHERE user_email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if (wp_check_password($password, $user['user_pass'])) {
                $_SESSION['passenger_logged_in'] = true;
                $_SESSION['passenger_id'] = $user['ID'];
                $_SESSION['user_login'] = $user['user_login'];
$_SESSION['passenger_name'] = $user['display_name']; // optional, still available

                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Mot de passe incorrect.";
            }
        } else {
            $error = "Utilisateur non trouvé.";
        }

        $stmt->close();
    } else {
        $error = "Veuillez remplir tous les champs.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion Passager</title>
</head>

<body>    
    <h2>Connexion Passager</h2>
    <?php if ($error): ?>
        <p style="color:red;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST">
                <p class="back-link"><a href="/dispatch/index.php">← Retour à l'accueil</a></p>

        <label>Email :</label><br>
        <input type="email" name="email" required><br>
        <label>Mot de passe :</label><br>
        <input type="password" name="password" required><br><br>
        <button type="submit">Se connecter</button>
        
    </form>
    
    <p><a href="forgot-password.php">Mot de passe oublié ?</a></p>

    <p><a href="/dispatch/passenger/register.php">Créer un compte passager</a></p>

</body>
</html>
