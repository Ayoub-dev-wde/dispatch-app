<?php
require_once __DIR__ . '/../shared/inc/db_connect.php';
require_once __DIR__ . '/../shared/inc/PasswordHash.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = trim($_POST['prenom'] ?? '');
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($prenom) || empty($nom) || empty($email) || empty($password)) {
        $errors[] = "Tous les champs sont requis.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email invalide.";
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT ID FROM wp_users WHERE user_email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors[] = "Un compte existe déjà avec cet email.";
    }
    $stmt->close();

    if (empty($errors)) {
        $full_name = $prenom . ' ' . $nom;
        $nicename = strtolower(str_replace(' ', '', $full_name));
        $hasher = new PasswordHash(8, true);
        $hashed_password = $hasher->HashPassword($password);

        $now = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("INSERT INTO wp_users (user_login, user_pass, user_nicename, user_email, user_registered, display_name) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $email, $hashed_password, $nicename, $email, $now, $full_name);
        $success = $stmt->execute();
        if (!$success) {
            $errors[] = "Erreur lors de l'enregistrement.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription Passager</title>
</head>
<body>
    <h1>Créer un compte passager</h1>

    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <ul>
                <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php elseif ($success): ?>
        <div style="color: green;">Inscription réussie ! Vous pouvez maintenant <a href="login.php">vous connecter</a>.</div>
    <?php endif; ?>

    <form method="post">
        <label for="prenom">Prénom :</label><br>
        <input type="text" name="prenom" id="prenom" required><br><br>

        <label for="nom">Nom :</label><br>
        <input type="text" name="nom" id="nom" required><br><br>

        <label for="email">Email :</label><br>
        <input type="email" name="email" id="email" required><br><br>

        <label for="password">Mot de passe :</label><br>
        <input type="password" name="password" id="password" required><br><br>

        <button type="submit">S'inscrire</button>
    </form>
</body>
</html>
