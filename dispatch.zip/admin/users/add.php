<?php
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);  // Secure password storage

    if ($name !== '' && $email !== '' && $_POST['password'] !== '') {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);
        $stmt->execute();

        header("Location: index.php");
        exit();
    } else {
        $error = "Le nom, l'email et le mot de passe sont obligatoires.";
    }
}
?>

<h2>Ajouter un Utilisateur</h2>

<?php if (!empty($error)): ?>
    <p style="color:red"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<form method="post">
    <label>Nom: <input type="text" name="name" required></label><br><br>
    <label>Email: <input type="email" name="email" required></label><br><br>
    <label>Mot de passe: <input type="password" name="password" required></label><br><br>
    <button type="submit">Ajouter</button>
    <a href="index.php">Annuler</a>
</form>

<?php require_once __DIR__ . '/../../shared/inc/admin/footer.php'; ?>
