<?php
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Check if an ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit();
}

// Fetch the user record from the database
$id = (int) $_GET['id'];
$sql = "SELECT * FROM users WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Utilisateur non trouvé.";
    exit();
}

$user = $result->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // If password is empty, do not update it
    if (!empty($password)) {
        $password = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $email, $password, $id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $email, $id);
    }
    $stmt->execute();

    header("Location: index.php");
    exit();
}
?>

<h2>Modifier l'Utilisateur</h2>

<form method="post">
    <label>Nom: <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required></label><br><br>
    <label>Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required></label><br><br>
    <label>Mot de passe: <input type="password" name="password"></label><br><br>
    <button type="submit">Mettre à jour</button>
    <a href="index.php">Annuler</a>
</form>

<?php require_once __DIR__ . '/../../shared/inc/admin/footer.php'; ?>
