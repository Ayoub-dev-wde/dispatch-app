<?php
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Fetch users from the database
$sql = "SELECT * FROM users";  // Assuming there's a users table in your database
$result = $conn->query($sql);
?>

<h2>Liste des Utilisateurs</h2>

<a href="add.php">➕ Ajouter un Utilisateur</a>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id'] ?>">✏️ Modifier</a> |
                        <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Supprimer cet utilisateur ?');">🗑️ Supprimer</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="4">Aucun utilisateur trouvé.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../../shared/inc/admin/footer.php'; ?>
