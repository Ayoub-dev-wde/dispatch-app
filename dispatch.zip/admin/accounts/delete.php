<?php
require_once __DIR__ . '/../../shared/inc/config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$account_id = (int)$_GET['id'];

// Delete related transactions first
$sql = "DELETE FROM account_transactions WHERE account_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $account_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

// Now delete the account
$sql = "DELETE FROM accounts WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $account_id);
if ($stmt->execute()) {
    header('Location: index.php?msg=deleted');
    exit;
} else {
    echo "Error deleting account: " . $conn->error;
}
?>
