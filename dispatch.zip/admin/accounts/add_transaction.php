<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

$pageTitle = "Ajouter une transaction";

$account_id = isset($_GET['account_id']) ? (int)$_GET['account_id'] : 0;
if (!$account_id) {
    die("Compte invalide.");
}

// Fetch driver name for the account
$stmt = $conn->prepare("SELECT a.id, d.name AS driver_name FROM accounts a LEFT JOIN drivers d ON a.driver_id = d.id WHERE a.id = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $account_id);
$stmt->execute();
$account = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$account) {
    die("Compte introuvable.");
}

$errors = [];
$trip_order_number = '';
$cod = 0.00;
$online = 0.00;
$date = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $trip_order_number = trim($_POST['trip_order_number'] ?? '');
    $cod = floatval($_POST['payment_cod'] ?? 0);
    $online = floatval($_POST['payment_online'] ?? 0);
    $date = $_POST['date'] ?? '';

    if ($trip_order_number === '') {
        $errors[] = "Le numéro de commande est obligatoire.";
    }
    if ($cod < 0 || $online < 0) {
        $errors[] = "Les montants ne peuvent pas être négatifs.";
    }
    if ($cod == 0 && $online == 0) {
        $errors[] = "Au moins un montant (COD ou Online) doit être supérieur à zéro.";
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $errors[] = "La date est invalide.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO account_transactions (account_id, trip_order_number, payment_cod, payment_online, date) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("issds", $account_id, $trip_order_number, $cod, $online, $date);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: view.php?id=$account_id");
            exit;
        } else {
            $errors[] = "Erreur lors de l'ajout de la transaction: " . $stmt->error;
        }
    }
}
?>

<div class="page-content">
    <h2>Ajouter une transaction pour <?= htmlspecialchars($account['driver_name']) ?></h2>

    <?php if (!empty($errors)): ?>
        <div class="error-messages">
            <?php foreach ($errors as $error): ?>
                <p>❌ <?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="transaction-form">
        <label for="trip_order_number">Numéro de commande :</label>
        <input type="text" id="trip_order_number" name="trip_order_number" required value="<?= htmlspecialchars($trip_order_number) ?>">

        <label for="payment_cod">Montant COD (€) :</label>
        <input type="number" id="payment_cod" name="payment_cod" step="0.01" min="0" value="<?= htmlspecialchars($cod) ?>">

        <label for="payment_online">Montant Online (€) :</label>
        <input type="number" id="payment_online" name="payment_online" step="0.01" min="0" value="<?= htmlspecialchars($online) ?>">

        <label for="date">Date :</label>
        <input type="date" id="date" name="date" required value="<?= htmlspecialchars($date) ?>">

        <div class="form-actions">
            <button type="submit" class="btn-submit">Ajouter</button>
            <a href="view.php?id=<?= $account_id ?>" class="btn-cancel">Annuler</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../shared/inc/footer.php'; ?>
