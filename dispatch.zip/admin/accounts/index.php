<?php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', true);
$pageTitle = "Commissions";
$breadcrumbs = [];

// connection setup (adjust to your config)
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Fetch accounts data
$sql = "SELECT a.id, d.name AS driver_name, a.balance_cod, a.balance_online
        FROM accounts a
        LEFT JOIN drivers d ON a.driver_id = d.id
        ORDER BY a.id DESC";

$result = $conn->query($sql);

// Initialize summary counters
$total_commissions = 0;
$total_company_amount = 0;
$total_cod = 0;
$total_online = 0;

if ($result && $result->num_rows > 0) {
    // Rewind to start for iteration (to calculate sums)
    $result->data_seek(0);
    while ($acc = $result->fetch_assoc()) {
        $balance_cod = (float)$acc['balance_cod'];
        $balance_online = (float)$acc['balance_online'];
        $solde = $balance_cod + $balance_online;
        $commission = $solde * 0.8;

        $total_commissions += $commission;
        $total_company_amount += $solde;
        $total_cod += $balance_cod;
        $total_online += $balance_online;
    }
}

function format_euro($num) {
    return number_format($num, 2, ',', ' ') . " €";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Accounts List</title>
    <style>
        table {border-collapse: collapse; width: 100%;}
        th, td {border: 1px solid #ddd; padding: 8px; text-align: right;}
        th {background-color: #f2f2f2; text-align: center;}
        td.name, th.name {text-align: left;}
        #searchInput {
            margin-bottom: 1em;
            padding: 0.5em;
            width: 300px;
            font-size: 1em;
        }
        .summary {
            margin-bottom: 1em;
            font-weight: bold;
        }
        a {
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h2>Accounts</h2>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
    <p style="color: green; font-weight: bold;">Le compte a été supprimé avec succès.</p>
<?php endif; ?>

<label for="searchInput">Search Accounts:</label>
<input type="text" id="searchInput" placeholder="Search by driver name or ID">

<div class="summary">
    Received by cash (COD): <?= format_euro($total_cod) ?> /
    Company credit (Online): <?= format_euro($total_online) ?> /
    Solde total: <?= format_euro($total_company_amount) ?> /
    Commissions amount: <?= format_euro($total_commissions) ?> /
 
   
</div>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th class="name">Driver</th>
            <th>Balance COD (€)</th>
            <th>Balance Online (€)</th>
            <th>Solde (€)</th>
            <th>Commission (80%) (€)</th>
            <th>Solde Chauffeur (€)</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php
            // Reset pointer again for display
            $result->data_seek(0);
            ?>
            <?php while ($account = $result->fetch_assoc()): ?>
                <?php
                    $balance_cod = (float)$account['balance_cod'];
                    $balance_online = (float)$account['balance_online'];
                    $solde = $balance_cod + $balance_online;
                    $commission = $solde * 0.8;
                    $solde_chauffeur = ($balance_online * 0.8) - ($balance_cod * 0.2);

                    // Format numbers French style
                    $balance_cod_f = number_format($balance_cod, 2, ',', ' ');
                    $balance_online_f = number_format($balance_online, 2, ',', ' ');
                    $solde_f = number_format($solde, 2, ',', ' ');
                    $commission_f = number_format($commission, 2, ',', ' ');

                    $solde_chauffeur_sign = ($solde_chauffeur < 0) ? '-' : '+';
                    $solde_chauffeur_f = $solde_chauffeur_sign . number_format(abs($solde_chauffeur), 2, ',', ' ');
                ?>
                <tr>
                    <td><?= htmlspecialchars($account['id']) ?></td>
                    <td class="name"><?= htmlspecialchars($account['driver_name'] ?? 'N/A') ?></td>
                    <td><?= $balance_cod_f ?></td>
                    <td><?= $balance_online_f ?></td>
                    <td><?= $solde_f ?></td>
                    <td><?= $commission_f ?></td>
                    <td><?= $solde_chauffeur_f ?></td>
                    <td>
                        <a href="view.php?id=<?= $account['id'] ?>">View</a> |
                        <a href="edit.php?id=<?= $account['id'] ?>">Edit</a> |
                        <a href="delete.php?id=<?= $account['id'] ?>" onclick="return confirm('Are you sure you want to delete this account?');" style="color:red;">Delete</a> |
                        <a href="generate_invoice.php?id=<?= $account['id'] ?>" target="_blank" style="color:blue;">Invoice</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8" style="text-align:center;">No accounts found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<script>
// Real-time search filter
document.getElementById('searchInput').addEventListener('input', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('tbody tr');

    rows.forEach(row => {
        const driverName = row.querySelector('td.name').textContent.toLowerCase();
        const id = row.querySelector('td:first-child').textContent.toLowerCase();

        if (driverName.includes(filter) || id.includes(filter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});
</script>

</body>
</html>
