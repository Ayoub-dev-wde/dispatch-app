<?php
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Commissions', 'url' => 'index.php'],
    ['label' => 'Modifier le compte']
];
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Simple CSRF token
if (!isset($_SESSION)) session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    echo "ID de compte invalide.";
    exit;
}

$errors = [];
$success = false;
$selected_driver = null;

// Fetch account
$stmt = $conn->prepare("SELECT * FROM accounts WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$account = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$account) {
    echo "Compte introuvable.";
    exit;
}

// Fetch drivers
$drivers = [];
$resultDrivers = $conn->query("SELECT id, name FROM drivers ORDER BY name");
if ($resultDrivers) {
    while ($row = $resultDrivers->fetch_assoc()) {
        $drivers[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Jeton CSRF invalide. Veuillez réessayer.";
    }

    $selected_driver = isset($_POST['driver_id']) ? (int)$_POST['driver_id'] : null;

    if (!$selected_driver) {
        $errors[] = "Veuillez sélectionner un chauffeur.";
    } else {
        // Check if another account exists with this driver (exclude current)
        $check = $conn->prepare("SELECT id FROM accounts WHERE driver_id = ? AND id != ? LIMIT 1");
        $check->bind_param("ii", $selected_driver, $id);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $errors[] = "Ce chauffeur a déjà un compte.";
        }
        $check->close();
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE accounts SET driver_id = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("ii", $selected_driver, $id);
        if ($stmt->execute()) {
            $stmt->close();
            // Prevent resubmission
            unset($_SESSION['csrf_token']);
            header("Location: index.php?updated=1");
            exit;
        } else {
            $errors[] = "Erreur lors de la mise à jour du compte.";
        }
    }
} else {
    $selected_driver = $account['driver_id'];
}
?>

<div class="page-content">
    <h2>🛠 Modifier le Compte</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p>❌ <?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="form-edit-account">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

        <label for="driver_id">👤 Chauffeur :</label>
        <select name="driver_id" id="driver_id" required>
            <option value="">-- Sélectionnez un chauffeur --</option>
            <?php foreach ($drivers as $driver): ?>
                <option value="<?= $driver['id'] ?>" <?= ($driver['id'] == $selected_driver) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($driver['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <p class="note"><em>ℹ️ Les soldes sont calculés automatiquement à partir des transactions et ne peuvent pas être modifiés ici.</em></p>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">💾 Mettre à jour</button>
            <a href="index.php" class="btn btn-secondary">↩️ Annuler</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../shared/inc/footer.php'; ?>
