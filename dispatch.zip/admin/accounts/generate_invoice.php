<?php
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Commissions', 'url' => 'index.php'],
    ['label' => 'Facture']
];    
// generate_invoice.php
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('Invalid account ID');
}

$account_id = (int)$_GET['id'];

// Fetch account and driver info
$sql = "SELECT a.id, d.name AS driver_name
        FROM accounts a
        LEFT JOIN drivers d ON a.driver_id = d.id
        WHERE a.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $account_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('Account not found');
}

$account = $result->fetch_assoc();

// Fetch account transactions
$sqlTrans = "SELECT trip_order_number, payment_cod, payment_online, amount, date, created_at 
             FROM account_transactions 
             WHERE account_id = ? 
             ORDER BY date DESC, created_at DESC";
$stmtTrans = $conn->prepare($sqlTrans);
$stmtTrans->bind_param('i', $account_id);
$stmtTrans->execute();
$transactions = $stmtTrans->get_result();

$total = 0;
$rows = [];

while ($trans = $transactions->fetch_assoc()) {
    $rows[] = $trans;
    $total += (float)$trans['amount']; // Sum total amount
}

function format_euro($num) {
    return number_format($num, 2, ',', ' ') . " €";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Invoice for Account #<?= htmlspecialchars($account_id) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2em; }
        h1 { margin-bottom: 0.2em; }
        table { border-collapse: collapse; width: 100%; margin-top: 1em; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
        tfoot td { font-weight: bold; }
        .print-button {
            margin-top: 1em;
            padding: 0.5em 1em;
            font-size: 1em;
            cursor: pointer;
        }
    </style>
</head>
<body>

<h1>Invoice for Account #<?= htmlspecialchars($account_id) ?></h1>
<p><strong>Driver:</strong> <?= htmlspecialchars($account['driver_name'] ?? 'N/A') ?></p>
<p><strong>Date:</strong> <?= date('d/m/Y') ?></p>

<table>
    <thead>
        <tr>
            <th>Date de la course</th>
            <th>Numéro de course</th>
            <th>Paiement en espèces (COD)</th>
            <th>Paiement en ligne</th>
            <th>Commission (80%) (€)</th>
            <th>Solde Chauffeur (€)</th>
            <th>Montant total (€)</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if (count($rows) === 0): ?>
            <tr><td colspan="7" style="text-align:center;">Aucune transaction trouvée.</td></tr>
        <?php else: 
            // Initialize totals for the bottom row
            $total_cod = 0;
            $total_online = 0;
            $total_commission = 0;
            $total_solde_chauffeur = 0;
            $total_amount = 0;

            foreach ($rows as $r): 
                // Assuming your $r array has fields for:
                // date_course, trip_number, payment_cod, payment_online, amount, etc.
                // You'll have to adapt field names as per your DB.

                // For example, if these values are stored in 'amount_cod' and 'amount_online':
                $cod = isset($r['payment_cod']) ? (float)$r['payment_cod'] : 0;
                $online = isset($r['payment_online']) ? (float)$r['payment_online'] : 0;
                $amount = isset($r['amount']) ? (float)$r['amount'] : 0;

                // Commission (80%) on total payment (COD + Online)
                $commission = ($cod + $online) * 0.80;

                // Solde Chauffeur calculation same as before
                $chauffeur_cod = -($cod * 0.20);
                $chauffeur_online = $online * 0.80;
                $solde_chauffeur = $chauffeur_cod + $chauffeur_online;

                // Sum totals for footer
                $total_cod += $cod;
                $total_online += $online;
                $total_commission += $commission;
                $total_solde_chauffeur += $solde_chauffeur;
                $total_amount += $amount;
        ?>
            <tr>
                <td><?= htmlspecialchars(date('d/m/Y', strtotime($r['date_course'] ?? $r['created_at']))) ?></td>
                <td><?= htmlspecialchars($r['trip_order_number'] ?? 'N/A') ?></td>
                <td style="text-align:right;"><?= format_euro($cod) ?></td>
                <td style="text-align:right;"><?= format_euro($online) ?></td>
                <td style="text-align:right;"><?= format_euro($commission) ?></td>
                <td style="text-align:right;"><?= ($solde_chauffeur < 0 ? '-' : '') . format_euro(abs($solde_chauffeur)) ?></td>
                <td style="text-align:right;"><?= format_euro($amount) ?></td>
            </tr>
        <?php 
            endforeach;
        endif; 
        ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="2" style="text-align:right;"><strong>Total</strong></td>
            <td style="text-align:right;"><strong><?= format_euro($total_cod) ?></strong></td>
            <td style="text-align:right;"><strong><?= format_euro($total_online) ?></strong></td>
            <td style="text-align:right;"><strong><?= format_euro($total_commission) ?></strong></td>
            <td style="text-align:right;">
                <strong>
                <?= format_euro($total_solde_chauffeur) ?>
                </strong>
            </td>
            <td style="text-align:right;"><strong><?= format_euro($total_amount) ?></strong></td>
        </tr>
    </tfoot>
</table>


<button class="print-button" onclick="window.print()">Imprimer la facture</button>

</body>
</html>
