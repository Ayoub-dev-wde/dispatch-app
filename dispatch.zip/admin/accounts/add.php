<?php
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Commissions', 'url' => 'index.php'],
    ['label' => 'Ajouter un compte']
];
require_once __DIR__ . '../../shared/inc/bootstrap_admin.php';

$errors = [];
$drivers = [];
$selected_driver = null;

// Fetch drivers for dropdown
$resultDrivers = $conn->query("SELECT id, name FROM drivers ORDER BY name");
if ($resultDrivers) {
    while ($row = $resultDrivers->fetch_assoc()) {
        $drivers[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_driver = isset($_POST['driver_id']) ? (int)$_POST['driver_id'] : null;

    if (!$selected_driver) {
        $errors[] = "Veuillez sélectionner un chauffeur.";
    }

    // Check if driver already has an account
    if ($selected_driver) {
        $check = $conn->prepare("SELECT id FROM accounts WHERE driver_id = ? LIMIT 1");
        $check->bind_param("i", $selected_driver);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $errors[] = "Ce chauffeur a déjà un compte.";
        }
        $check->close();
    }

    if (empty($errors)) {
        // Insert account with zero balances (balances managed dynamically)
        $stmt = $conn->prepare("INSERT INTO accounts (driver_id, balance_cod, balance_online, created_at, updated_at) VALUES (?, 0, 0, NOW(), NOW())");
        $stmt->bind_param("i", $selected_driver);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: index.php");
            exit;
        } else {
            $errors[] = "Erreur lors de l'ajout du compte.";
        }
    }
}
?>

<div class="page-content">
    <h2>Ajouter un Compte Chauffeur</h2>

    <?php if ($errors): ?>
        <div class="error-messages">
            <?php foreach ($errors as $error): ?>
                <p>❌ <?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="account-form">
        <label for="driver_id">Chauffeur :</label>
        <select name="driver_id" id="driver_id" required>
            <option value="">-- Sélectionnez un chauffeur --</option>
            <?php foreach ($drivers as $driver): ?>
                <option value="<?= $driver['id'] ?>" <?= ($driver['id'] == $selected_driver) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($driver['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <div class="form-actions">
            <button type="submit" class="btn-submit">Ajouter</button>
            <a href="index.php" class="btn-cancel">Annuler</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../inc/footer.php'; ?>
