<?php
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Commissions', 'url' => 'index.php'],
    ['label' => 'Modifier le compte']
];    
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$account_id = (int)$_GET['id'];

// Fetch account and linked driver info
$sql = "SELECT a.id, a.driver_id, a.balance_cod, a.balance_online, d.name AS driver_name
        FROM accounts a
        LEFT JOIN drivers d ON a.driver_id = d.id
        WHERE a.id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $account_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$account = mysqli_fetch_assoc($result);

if (!$account) {
    echo "Account not found.";
    exit;
}

$balance_cod = (float)$account['balance_cod'];
$balance_online = (float)$account['balance_online'];
$solde_total = $balance_cod + $balance_online;

// Calculations
$commission = $solde_total * 0.80;

// Solde chauffeur calculation:
// COD: chauffeur pays company 20% → show as negative 20% of balance_cod
$chauffeur_cod = -($balance_cod * 0.20);
// Online: company pays chauffeur 80% → positive 80% of balance_online
$chauffeur_online = $balance_online * 0.80;
$solde_chauffeur = $chauffeur_cod + $chauffeur_online;

// Fetch all transactions for this account
$sql = "SELECT trip_order_number, payment_cod, payment_online, amount, date, created_at
        FROM account_transactions
        WHERE account_id = ?
        ORDER BY date DESC, created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $account_id);
mysqli_stmt_execute($stmt);
$transactions = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails du Compte Chauffeur: <?= htmlspecialchars($account['driver_name']) ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
      .buttons {
        margin-bottom: 1em;
      }
      .buttons a {
        display: inline-block;
        margin-right: 1em;
        padding: 0.5em 1em;
        background-color: #2c7;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        font-weight: bold;
      }
      .buttons a.back {
        background-color: #888;
      }
      .account-summary {
        margin-bottom: 1em;
        font-size: 1.1em;
      }
      .account-summary p {
        margin: 0.3em 0;
      }
    </style>
</head>
<body>
    <h1>Détails du Compte Chauffeur</h1>
    
    <div class="account-summary">
        <p><strong>Chauffeur :</strong> <?= htmlspecialchars($account['driver_name']) ?></p>
        <p><strong>Solde total :</strong> <?= number_format($solde_total, 2, ',', ' ') ?> €</p>
        <p><strong>Solde COD :</strong> <?= number_format($balance_cod, 2, ',', ' ') ?> €</p>
        <p><strong>Solde Online :</strong> <?= number_format($balance_online, 2, ',', ' ') ?> €</p>
        <hr>
        <p><strong>Commission (80%) :</strong> <?= number_format($commission, 2, ',', ' ') ?> €</p>
        <p><strong>Solde Chauffeur :</strong> <?= ($solde_chauffeur < 0 ? '-' : '+') . ' ' . number_format(abs($solde_chauffeur), 2, ',', ' ') ?> €</p>
    </div>

    <div class="buttons">
    <a href="add_transaction.php?account_id=<?= $account_id ?>">➕ Ajouter une transaction</a>
    <a href="index.php" class="back">← Retour à la liste</a>
</div>


    <h2>Transactions</h2>

    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>Numéro de course</th>
                <th>Paiement en espèces (COD)</th>
                <th>Paiement en ligne</th>
                <th>Montant total</th>
                <th>Date de la course</th>
                <th>Créé le</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($transactions) === 0): ?>
                <tr><td colspan="6">Aucune transaction trouvée.</td></tr>
            <?php else: ?>
                <?php while ($row = mysqli_fetch_assoc($transactions)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['trip_order_number']) ?></td>
                        <td><?= number_format($row['payment_cod'], 2, ',', ' ') ?> €</td>
                        <td><?= number_format($row['payment_online'], 2, ',', ' ') ?> €</td>
                        <td><?= number_format($row['amount'], 2, ',', ' ') ?> €</td>
                        <td><?= htmlspecialchars($row['date']) ?></td>
                        <td><?= htmlspecialchars($row['created_at']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
