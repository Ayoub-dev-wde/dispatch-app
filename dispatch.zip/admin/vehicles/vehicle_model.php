<?php
require_once __DIR__ . '/../../shared/config.php';

function get_all_vehicles($conn) {
    $sql = "SELECT id, make, model, year, license_plate, status FROM vehicles ORDER BY id DESC";
    return $conn->query($sql);
}

// Fetch vehicle by ID with driver_id
function get_vehicle_by_id($conn, $id) {
    $stmt = $conn->prepare("SELECT id, make, model, year, license_plate, status, driver_id FROM vehicles WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Create vehicle with optional driver_id
function create_vehicle($conn, $make, $model, $year, $license_plate, $status, $driver_id = null) {
    $stmt = $conn->prepare("INSERT INTO vehicles (make, model, year, license_plate, status, driver_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssissi", $make, $model, $year, $license_plate, $status, $driver_id);
    return $stmt->execute();
}

// Update vehicle with driver_id
function update_vehicle($conn, $id, $make, $model, $year, $license_plate, $status, $color, $comment, $photo) {
    $sql = "UPDATE vehicles SET make=?, model=?, year=?, license_plate=?, status=?, color=?, comment=?, photo=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssssi", $make, $model, $year, $license_plate, $status, $color, $comment, $photo, $id);
    return $stmt->execute();
}


function delete_vehicle($conn, $id) {
    $stmt = $conn->prepare("DELETE FROM vehicles WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

