<?php
require_once __DIR__ . '/../../shared/config.php';

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID du véhicule manquant.";
    exit;
}

$vehicle_id = intval($_GET['id']);

// Delete the vehicle
$stmt = $conn->prepare("DELETE FROM vehicles WHERE id = ?");
$stmt->bind_param("i", $vehicle_id);

if ($stmt->execute()) {
    // Redirect back to vehicles index page after deletion
    header("Location: index.php?message=Véhicule supprimé avec succès");
    exit;
} else {
    echo "Erreur lors de la suppression : " . $stmt->error;
}

$stmt->close();
?>