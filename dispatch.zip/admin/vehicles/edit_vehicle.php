
<?php
ob_start(); // Start output buffering to prevent header issues

$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Gestion des véhicules', 'url' => 'index.php'],
    ['label' => 'Modifier la véhicule']
];

require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';
 // Loads config + UI (may send output)

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: index.php');
    exit;
}

// Fetch the vehicle from DB
$stmt = $conn->prepare("SELECT * FROM vehicles WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$vehicle = $result->fetch_assoc();
if (!$vehicle) {
    header('Location: index.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $make = $_POST['make'] ?? '';
    $model = $_POST['model'] ?? '';
    $year = $_POST['year'] ?? '';
    $license_plate = $_POST['license_plate'] ?? '';
    $status = $_POST['status'] ?? 'available';
    $color = $_POST['color'] ?? '';
    $comment = $_POST['comment'] ?? '';
    $photo = $vehicle['photo'];

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/admin/vehicles/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

        $tmpName = $_FILES['photo']['tmp_name'];
        $fileName = basename($_FILES['photo']['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif'];

        if (in_array($fileExt, $allowed)) {
            $newFileName = uniqid('vehicle_') . '.' . $fileExt;
            $destination = $uploadDir . $newFileName;
            if (move_uploaded_file($tmpName, $destination)) {
                if ($photo && file_exists(__DIR__ . '/' . $photo)) {
                    unlink(__DIR__ . '/' . $photo);
                }
                $photo = 'uploads/admin/vehicles/' . $newFileName;
            }
        }
    }

    $sql = "UPDATE vehicles SET make=?, model=?, year=?, license_plate=?, status=?, color=?, comment=?, photo=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssssi", $make, $model, $year, $license_plate, $status, $color, $comment, $photo, $id);

    if ($stmt->execute()) {
        header("Location: index.php?msg=Véhicule mis à jour avec succès");
        exit;
    } else {
        $error = "Erreur : " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Modifier le véhicule</title>
</head>
<body>
    <main class="vehicle-edit">
        <h1 class="vehicle-edit__title">Modifier le véhicule</h1>

        <?php if ($error): ?>
            <p class="vehicle-edit__error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form class="vehicle-form" action="edit_vehicle.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data" novalidate>
            <label class="vehicle-form__label" for="make">Marque :</label>
            <input class="vehicle-form__input" type="text" name="make" id="make" value="<?= htmlspecialchars($vehicle['make']) ?>" required>

            <label class="vehicle-form__label" for="model">Modèle :</label>
            <input class="vehicle-form__input" type="text" name="model" id="model" value="<?= htmlspecialchars($vehicle['model']) ?>" required>

            <label class="vehicle-form__label" for="year">Année :</label>
            <input class="vehicle-form__input" type="number" name="year" id="year" value="<?= htmlspecialchars($vehicle['year']) ?>" required>

            <label class="vehicle-form__label" for="license_plate">Plaque d'immatriculation :</label>
            <input class="vehicle-form__input" type="text" name="license_plate" id="license_plate" value="<?= htmlspecialchars($vehicle['license_plate']) ?>" required>

            <label class="vehicle-form__label" for="status">Statut :</label>
            <select class="vehicle-form__select" name="status" id="status">
               <option value="active" <?= $vehicle['status'] == 'active' ? 'selected' : '' ?>>Disponible</option>
<option value="inactive" <?= $vehicle['status'] == 'inactive' ? 'selected' : '' ?>>Indisponible</option>

              
            </select>

            <label class="vehicle-form__label" for="color">Couleur :</label>
            <input class="vehicle-form__input" type="text" name="color" id="color" value="<?= htmlspecialchars($vehicle['color']) ?>">

            <label class="vehicle-form__label" for="comment">Commentaire :</label>
            <textarea class="vehicle-form__textarea" name="comment" id="comment"><?= htmlspecialchars($vehicle['comment']) ?></textarea>

            <label class="vehicle-form__label">Photo actuelle :</label>
            <?php if ($vehicle['photo']): ?>
                <img class="vehicle-form__photo-preview" src="<?= htmlspecialchars($vehicle['photo']) ?>" alt="Photo du véhicule">
            <?php else: ?>
                <p class="vehicle-form__no-photo">Aucune photo téléchargée.</p>
            <?php endif; ?>

            <label class="vehicle-form__label" for="photo">Changer la photo (optionnel) :</label>
            <input class="vehicle-form__file" type="file" name="photo" id="photo" accept="image/*">

            <button class="vehicle-form__submit" type="submit">Mettre à jour</button>
        </form>

        <p class="vehicle-edit__back-link"><a href="index.php">← Retour à la liste</a></p>
    </main>
</body>
<link href="/dispatch/shared/assets/css/vehicles.css" rel="stylesheet">
</html>

<?php ob_end_flush(); ?>