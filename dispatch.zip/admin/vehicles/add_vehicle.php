<?php
// Show errors for development (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Load DB config only (no layout yet)
require_once __DIR__ . '/../../shared/inc/config.php';

$error = null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $make = $_POST['make'] ?? '';
    $model = $_POST['model'] ?? '';
    $year = $_POST['year'] ?? '';
    $license_plate = $_POST['license_plate'] ?? '';
    $status = $_POST['status'] ?? 'active';
    $color = $_POST['color'] ?? '';
    $comment = $_POST['comment'] ?? '';
    $photo = '';

    // Handle photo upload
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../../uploads/admin/vehicles/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $tmpName = $_FILES['photo']['tmp_name'];
        $fileName = basename($_FILES['photo']['name']);
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($ext, $allowed)) {
            $newFileName = uniqid('vehicle_') . '.' . $ext;
            $destination = $uploadDir . $newFileName;
            if (move_uploaded_file($tmpName, $destination)) {
                $photo = 'uploads/admin/vehicles/' . $newFileName;
            }
        }
    }

    $stmt = $conn->prepare("INSERT INTO vehicles (make, model, year, license_plate, status, color, comment, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisssss", $make, $model, $year, $license_plate, $status, $color, $comment, $photo);

    if ($stmt->execute()) {
        header("Location: index.php?msg=Véhicule ajouté avec succès");
        exit;
    } else {
        $error = "Erreur: " . $conn->error;
    }
}

// Now load layout
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';
?>

<div class="page-content">
    <h2>Ajouter un Véhicule</h2>

    <?php if ($error): ?>
        <p class="vehicle-form__error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form class="vehicle-form" action="add_vehicle.php" method="POST" enctype="multipart/form-data" novalidate>
        <label for="make">Marque:</label>
        <input type="text" name="make" id="make" required>

        <label for="model">Modèle:</label>
        <input type="text" name="model" id="model" required>

        <label for="year">Année:</label>
        <input type="number" name="year" id="year" required>

        <label for="license_plate">Immatriculation:</label>
        <input type="text" name="license_plate" id="license_plate" required>

        <label for="status">Statut :</label>
<select name="status" required>
  <option value="active">Disponible</option>
  <option value="inactive">Indisponible</option>
</select>



        <label for="color">Couleur:</label>
        <input type="text" name="color" id="color">

        <label for="comment">Commentaire / Remarques:</label>
        <textarea name="comment" id="comment"></textarea>

        <label for="photo">Photo (optionnelle):</label>
        <input type="file" name="photo" id="photo" accept="image/*">

        <button type="submit">Ajouter Véhicule</button>
    </form>

    <p><a href="index.php">⬅ Retour à la liste des véhicules</a></p>
</div>

<link href="/dispatch/shared/assets/css/vehicles.css" rel="stylesheet">

<?php
require_once __DIR__ . '/../../shared/inc/footer.php';
?>