<?php
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Gestion des véhicules', 'url' => 'index.php'],
    ['label' => 'Détails du véhicule'] // auto removed if same as title
];

require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

/* ─ Fetch vehicle ─ */
$stmt = $conn->prepare("SELECT * FROM vehicles WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$vehicle = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$vehicle) {
    header('Location: index.php');
    exit;
}

/* ─ Fetch drivers assigned to this vehicle ─ */
$stmt = $conn->prepare("SELECT id, name, phone, email, status FROM drivers WHERE vehicle_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$drivers = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vehicle Details</title>
    <link rel="stylesheet" href="vehicles.css">
</head>
<body>
<main class="vehicle-details">
    <h1 class="vehicle-details__title">Vehicle Details</h1>

    <!-- Vehicle information -->
    <section class="vehicle-details__info">
        <p><strong>Mark:</strong> <span class="vehicle-details__value"><?= htmlspecialchars($vehicle['make']) ?></span></p>
        <p><strong>Model:</strong> <span class="vehicle-details__value"><?= htmlspecialchars($vehicle['model']) ?></span></p>
        <p><strong>Year:</strong> <span class="vehicle-details__value"><?= htmlspecialchars($vehicle['year']) ?></span></p>
        <p><strong>License Plate:</strong> <span class="vehicle-details__value"><?= htmlspecialchars($vehicle['license_plate']) ?></span></p>
        <p><strong>Status:</strong> <span class="vehicle-details__value"><?= htmlspecialchars($vehicle['status']) ?></span></p>
        <p><strong>Color:</strong> <span class="vehicle-details__value"><?= htmlspecialchars($vehicle['color']) ?></span></p>
        <p><strong>Comment / Notes:</strong><br>
            <span class="vehicle-details__value"><?= nl2br(htmlspecialchars($vehicle['comment'])) ?></span></p>

        <?php if (!empty($vehicle['photo'])): ?>
            <img class="vehicle-details__photo" src="<?= htmlspecialchars($vehicle['photo']) ?>" alt="Vehicle photo">
        <?php endif; ?>
    </section>

    <!-- Assigned drivers -->
    <section class="vehicle-details__drivers">
        <h2>Assigned Drivers</h2>
        <?php if ($drivers->num_rows > 0): ?>
            <ul class="vehicle-details__driver-list">
                <?php while ($d = $drivers->fetch_assoc()): ?>
                    <li class="vehicle-details__driver-item">
                        <strong><?= htmlspecialchars($d['name']) ?></strong>
                        (<?= htmlspecialchars($d['status']) ?>)
                        – <?= htmlspecialchars($d['phone']) ?>
                        – <a href="mailto:<?= htmlspecialchars($d['email']) ?>"><?= htmlspecialchars($d['email']) ?></a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No drivers assigned to this vehicle.</p>
        <?php endif; ?>
    </section>

    <p class="vehicle-details__back-link">
        <a href="index.php">← Back to Vehicles List</a>
    </p>
</main>
</body>
<link href="/dispatch/shared/assets/css/vehicles.css" rel="stylesheet">

</html>
