<?php

$pageTitle = "Gestion des véhicules";
$breadcrumbs = [];
$showBackButton = false;
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Fetch all vehicles from database
$stmt = $conn->prepare("SELECT * FROM vehicles ORDER BY id DESC");
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
?>

<div class="page-content">
    <h2>Liste des véhicules</h2>
    <a href="add_vehicle.php" style="display:inline-block; margin-bottom:10px;">➕ Ajouter un Véhicule</a>
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%; max-width:900px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Année</th>
                <th>Immatriculation</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['make']) ?></td>
                    <td><?= htmlspecialchars($row['model']) ?></td>
                    <td><?= htmlspecialchars($row['year']) ?></td>
                    <td><?= htmlspecialchars($row['license_plate']) ?></td>
                    <td>
    <?php
        $statusLabel = match ($row['status']) {
            'active' => 'Disponible',
            'inactive' => 'Indisponible',
            default => 'Inconnu'
        };
        echo htmlspecialchars($statusLabel);
    ?>
</td>

                    <td>
                        <a href="show_vehicle.php?id=<?= $row['id'] ?>">Voir détails</a> |
                        <a href="edit_vehicle.php?id=<?= $row['id'] ?>">Modifier</a> |
                        <a href="delete_vehicle.php?id=<?= $row['id'] ?>" onclick="return confirm('Supprimer ce véhicule ?')">Supprimer</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<link href="/dispatch/shared/assets/css/vehicles.css" rel="stylesheet">

<?php
require_once __DIR__ . '/../../shared/inc/footer.php';
?>