<?php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', true);

$pageTitle = "Tableau de bord";
$breadcrumbs = [];
$showBackButton = false;

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
require_once __DIR__ . '/../shared/inc/bootstrap_admin.php';


if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit();
}

// Database queries
$drivers_count = $conn->query("SELECT COUNT(*) FROM drivers")->fetch_row()[0];

$dispatch_query = new WP_Query([
    'post_type' => 'mptbm_booking',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'meta_query' => [
        'relation' => 'AND',
        ['key' => 'mptbm_driver_name', 'value' => '', 'compare' => '!='],
        ['key' => 'mptbm_driver_name', 'value' => 'Non assigné', 'compare' => '!=']
    ],
    'fields' => 'ids',
]);
$dispatch_count = $dispatch_query->post_count;

$balances = $conn->query("SELECT 
    COALESCE(SUM(balance_cod),0) AS total_cod, 
    COALESCE(SUM(balance_online),0) AS total_online 
    FROM accounts")->fetch_assoc();

$total_balance = (float)$balances['total_cod'] + (float)$balances['total_online'];

$payments_result = $conn->query("SELECT 
    COALESCE(SUM(payment_cod), 0) AS total_cod, 
    COALESCE(SUM(payment_online), 0) AS total_online 
    FROM account_transactions");
$payments = $payments_result ? $payments_result->fetch_assoc() : ['total_cod' => 0, 'total_online' => 0];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/dispatch/shared/assets/css/main_dashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-wrapper">
  <h2>📊 Tableau de Bord</h2>
  <div class="dashboard-cards">
    <div class="stat-card clickable" data-chart="chauffeurs">👨‍✈️ Chauffeurs : <strong><?= $drivers_count ?></strong></div>
    <div class="stat-card clickable" data-chart="dispatch">🚗 Courses Dispatchées : <strong><?= $dispatch_count ?></strong></div>
    <div class="stat-card clickable" data-chart="revenue">💰 Solde Total : <strong><?= number_format($total_balance, 2) ?> €</strong></div>
    <div class="stat-card clickable" data-chart="cod">💳 Paiement à bord : <strong><?= number_format($balances['total_cod'], 2) ?> €</strong></div>
    <div class="stat-card clickable" data-chart="online">🌐 Paiement en ligne : <strong><?= number_format($balances['total_online'], 2) ?> €</strong></div>
  </div>

  <hr>

  <h3>📈 Statistiques des 7 derniers jours</h3>
  <div class="charts-section">
    <canvas id="mainChart" width="800" height="350"></canvas>
    <p id="lastUpdated" class="last-updated">Dernière mise à jour: --</p>
  </div>
</div>

<script>
const ctx = document.getElementById('mainChart').getContext('2d');
let currentChartKey = 'revenue';
const chartDataCache = { chauffeurs: {}, revenue: {}, dispatch: {}, cod: {}, online: {} };

let chart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: '',
      data: [],
      backgroundColor: '',
      borderColor: '',
      borderWidth: 1,
      fill: true,
      tension: 0.3
    }]
  },
  options: { responsive: true, scales: { y: { beginAtZero: true } } }
});

function getLabel(key) {
  return {
    chauffeurs: 'Courses par Chauffeur (7 jours)',
    revenue: 'Revenus (€)',
    dispatch: 'Courses Dispatchées',
    cod: 'Paiement à bord (€)',
    online: 'Paiement en ligne (€)'
  }[key] || '';
}

function getColors(key) {
  const colors = {
    chauffeurs: ['rgba(54, 162, 235, 0.7)', 'rgba(54, 162, 235, 1)'],
    revenue: ['rgba(75,192,192,0.6)', 'rgba(75,192,192,1)'],
    dispatch: ['rgba(54,162,235,0.6)', 'rgba(54,162,235,1)'],
    cod: ['rgba(255,159,64,0.6)', 'rgba(255,159,64,1)'],
    online: ['rgba(153,102,255,0.6)', 'rgba(153,102,255,1)'],
  };
  return colors[key] || ['rgba(75,192,192,0.6)', 'rgba(75,192,192,1)'];
}

function updateChart(key) {
  if (!chartDataCache[key]) return;
  const [bg, border] = getColors(key);
  chart.destroy();
  chart = new Chart(ctx, {
    type: (key === 'chauffeurs') ? 'bar' : 'line',
    data: {
      labels: chartDataCache[key].labels,
      datasets: [{
        label: getLabel(key),
        data: chartDataCache[key].data,
        backgroundColor: bg,
        borderColor: border,
        borderWidth: 1,
        fill: true,
        tension: 0.3
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
  document.getElementById('lastUpdated').textContent = `Dernière mise à jour: ${new Date().toLocaleTimeString()}`;
}

async function fetchChartData() {
  const endpoints = ['chauffeurs', 'revenue', 'dispatch', 'cod', 'online'];
  for (let key of endpoints) {
    const response = await fetch(`/dispatch/admin/api/charts/chart_${key}.php`);
    if (response.ok) {
      const data = await response.json();
      chartDataCache[key] = { labels: data.labels, data: data.data };
    }
  }
  updateChart(currentChartKey);
}

fetchChartData();
setInterval(fetchChartData, 60000);

document.querySelectorAll('.stat-card.clickable').forEach(card => {
  card.addEventListener('click', () => {
    const key = card.getAttribute('data-chart');
    if (chartDataCache[key]) {
      currentChartKey = key;
      updateChart(key);
    }
  });
});
</script>
</body>
</html>
