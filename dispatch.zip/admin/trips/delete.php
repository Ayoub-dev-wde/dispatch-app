<?php
require_once __DIR__ . '/../../shared/inc/config.php';
require_once 'trip_model.php';

// Vérifie que l'ID est fourni
if (!isset($_GET['id'])) {
    die('Trip ID is required.');
}

$trip_id = (int) $_GET['id'];

// Appelle la suppression
$result = deleteTrip($conn, $trip_id);

if ($result) {
    header("Location: index.php?success=Trip deleted successfully.");
    exit;
} else {
    die('Failed to delete trip.');
}
?>
