<?php

// ----------  LOAD WORDPRESS IF NEEDED ----------
if ( !function_exists('get_post_meta') ) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

// ----------  GET POST ID FROM URL ----------
$postID = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ( $postID <= 0 ) {
    wp_die('Invalid trip ID.');
}

// ----------  VALIDATE POST TYPE ----------
if ( get_post_type( $postID ) !== 'mptbm_booking' ) {
    wp_die('Trip not found.');
}

// ----------  GET ORDER NUMBER ----------
$orderNumber = get_post_meta( $postID, 'mptbm_order_id', true );
if ( empty($orderNumber) ) {
    $orderNumber = 'Inconnu';
}

// ----------  SUBHEADER CONFIG ----------
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Réservations', 'url' => 'index.php'],
    ['label' => "{$orderNumber} Modifier"]
];
$showBackButton = true;

// ----------  RENDER SUBHEADER ----------
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';           // load WP + Woo

// ---- check -----------------------------------------------------------------
$post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$post_id || get_post_type($post_id) !== 'mptbm_booking') {
    exit('Invalid trip.');
}

// ---- fetch booking data ----------------------------------------------------
$order_number  = get_post_meta($post_id, 'mptbm_order_id', true);         // Woo order #
$billing_name  = get_post_meta($post_id, 'mptbm_billing_name', true);
$phone         = get_post_meta($post_id, 'mptbm_billing_phone', true);
$pickup        = get_post_meta($post_id, 'mptbm_start_place', true);
$destination   = get_post_meta($post_id, 'mptbm_end_place', true);
$base_price    = floatval(get_post_meta($post_id, 'mptbm_base_price', true));
$current_driver_id = intval(get_post_meta($post_id, 'driver_id', true));
$current_status    = get_post_meta($post_id, 'mptbm_order_status', true) ?: 'processing';

// ---- driver list for dropdown ---------------------------------------------
global $conn;                         // mysqli link from dispatch/config.php
$drivers = [];
$res = $conn->query("SELECT id, name FROM drivers ORDER BY name");
while ($row = $res->fetch_assoc()) {
    $drivers[$row['id']] = $row['name'];
}

// ---- handle save -----------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_admin_referer('save_trip_'.$post_id);

    $new_driver_id = intval($_POST['driver_id'] ?? 0);
    $new_status    = sanitize_text_field($_POST['order_status'] ?? $current_status);

    // 1. save driver info
    update_post_meta($post_id, 'driver_id', $new_driver_id);
    update_post_meta($post_id, 'mptbm_driver_name', $drivers[$new_driver_id] ?? '');

    // 2. save status in booking META only
    update_post_meta($post_id, 'mptbm_order_status', $new_status);

    // 3. sync WooCommerce order status (does NOT touch booking post_status)
    if (function_exists('wc_get_order') && $order_number) {
        $order = wc_get_order($order_number);
        if ($order && $order->get_status() !== $new_status) {
            $order->update_status($new_status, 'Updated from dispatch interface');
        }
    }

    // 4. credit driver only if account exists AND status changed from non-completed to completed
    if ($current_status !== 'completed' && $new_status === 'completed' && $new_driver_id && $base_price > 0) {
        // Get payment method from booking meta
        $payment_method = get_post_meta($post_id, 'mptbm_payment_method', true);

        $payment_cod = 0.0;
        $payment_online = 0.0;

        if ($payment_method === 'Paiement à bord') {
            $payment_cod = $base_price;
        } else {
            $payment_online = $base_price;
        }

        // Fetch current balances for the driver account
        $chk = $conn->prepare("SELECT id, balance_cod, balance_online FROM accounts WHERE driver_id = ? LIMIT 1");
        $chk->bind_param('i', $new_driver_id);
        $chk->execute();
        $chk->store_result();

        if ($chk->num_rows === 1) {
            $chk->bind_result($account_id, $current_balance_cod, $current_balance_online);
            $chk->fetch();
            $chk->close();

            $new_balance_cod = $current_balance_cod + $payment_cod;
            $new_balance_online = $current_balance_online + $payment_online;

            // Update accounts balances
            $upd = $conn->prepare("UPDATE accounts SET balance_cod = ?, balance_online = ?, updated_at = NOW() WHERE id = ?");
            $upd->bind_param('ddi', $new_balance_cod, $new_balance_online, $account_id);
            $upd->execute();
            $upd->close();

            // Insert transaction record in account_transactions
            $amount_total = $payment_cod + $payment_online;
            $ins = $conn->prepare("INSERT INTO account_transactions (account_id, trip_order_number, payment_cod, payment_online, amount, date, created_at) VALUES (?, ?, ?, ?, ?, CURDATE(), NOW())");
            $ins->bind_param("iisdd", $account_id, $order_number, $payment_cod, $payment_online, $amount_total);
            $ins->execute();
            $ins->close();
        } else {
            $chk->close();
            // Driver has no account, do nothing
        }
    }

    // refresh for redisplay
    $current_driver_id = $new_driver_id;
    $current_status    = $new_status;

    echo '<p style="color:green;">✅ Trip saved.</p>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Trip #<?= htmlspecialchars($order_number) ?></title>
</head>
<body>
<div class="edit-trip-container">
    <h2>Edit Trip #<?= htmlspecialchars($order_number) ?></h2>

    <form method="post">
        <?php wp_nonce_field('save_trip_'.$post_id); ?>

        <p><strong>Client :</strong> <?= htmlspecialchars($billing_name) ?></p>
        <p><strong>Phone :</strong>  <?= htmlspecialchars($phone) ?></p>
        <p><strong>Pickup :</strong> <?= htmlspecialchars($pickup) ?></p>
        <p><strong>Destination :</strong> <?= htmlspecialchars($destination) ?></p>
        <p><strong>Price (€) :</strong> <?= number_format($base_price,2) ?></p><hr>

        <!-- DRIVER DROPDOWN -->
        <label for="driver_id">Driver</label><br>
        <select name="driver_id" id="driver_id" required>
            <option value="">-- Select driver --</option>
            <?php foreach ($drivers as $id => $name): ?>
                <option value="<?= $id ?>" <?= $id === $current_driver_id ? 'selected' : '' ?>>
                    <?= htmlspecialchars($name) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <!-- PAYMENT / ORDER STATUS -->
        <label for="order_status">Payment status</label><br>
        <select name="order_status" id="order_status">
            <?php
            $labels = ['pending'=>'Pending','processing'=>'Processing','completed'=>'Completed','cancelled'=>'Cancelled'];
            foreach ($labels as $code => $label):
            ?>
                <option value="<?= $code ?>" <?= $code === $current_status ? 'selected' : '' ?>>
                    <?= $label ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <button type="submit">💾 Save</button>
    </form>

    <p><a href="index.php">← Back to list</a></p>
</div>
</body>
</html>
