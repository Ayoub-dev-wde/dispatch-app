<?php
// trip_model.php

function countAllTrips($conn, $search = '') {
    if (!empty($search)) {
        $searchLike = "%" . $search . "%";
        $sql = "SELECT COUNT(*) as total FROM trips 
                LEFT JOIN drivers ON trips.driver_id = drivers.id
                WHERE trips.id LIKE ? OR trips.wp_order_id LIKE ?
                OR trips.first_name LIKE ? OR trips.last_name LIKE ?
                OR trips.phone LIKE ? OR trips.email LIKE ?
                OR trips.pickup LIKE ? OR trips.destination LIKE ?
                OR trips.trip_date LIKE ? OR trips.pickup_time LIKE ?
                OR trips.transfer_type LIKE ? OR trips.vehicle_type LIKE ?
                OR trips.payment_type LIKE ? OR trips.status LIKE ?
                OR drivers.name LIKE ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssssssssss", 
            $searchLike, $searchLike, $searchLike, $searchLike, $searchLike,
            $searchLike, $searchLike, $searchLike, $searchLike, $searchLike,
            $searchLike, $searchLike, $searchLike, $searchLike, $searchLike
        );
    } else {
        $sql = "SELECT COUNT(*) as total FROM trips";
        $stmt = $conn->prepare($sql);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    return $result ? $result->fetch_assoc()['total'] : 0;
}

function getPaginatedTrips($conn, $limit, $offset, $sort = 'id', $order = 'desc', $search = '') {
    $allowedFields = ['id', 'wp_order_id', 'first_name', 'last_name', 'phone', 'email', 'pickup', 'destination', 'trip_date', 'pickup_time', 'transfer_type', 'vehicle_type', 'payment_type', 'base_price', 'status', 'drivers.name'];
    $sort = in_array($sort, $allowedFields) ? $sort : 'id';
    $order = strtolower($order) === 'asc' ? 'ASC' : 'DESC';

    if (!empty($search)) {
        $searchLike = "%" . $search . "%";
        $sql = "SELECT trips.*, drivers.name AS driver_name 
                FROM trips 
                LEFT JOIN drivers ON trips.driver_id = drivers.id
                WHERE trips.id LIKE ? OR trips.wp_order_id LIKE ?
                OR trips.first_name LIKE ? OR trips.last_name LIKE ?
                OR trips.phone LIKE ? OR trips.email LIKE ?
                OR trips.pickup LIKE ? OR trips.destination LIKE ?
                OR trips.trip_date LIKE ? OR trips.pickup_time LIKE ?
                OR trips.transfer_type LIKE ? OR trips.vehicle_type LIKE ?
                OR trips.payment_type LIKE ? OR trips.status LIKE ?
                OR drivers.name LIKE ?
                ORDER BY $sort $order
                LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssssssssssii", 
            $searchLike, $searchLike, $searchLike, $searchLike, $searchLike,
            $searchLike, $searchLike, $searchLike, $searchLike, $searchLike,
            $searchLike, $searchLike, $searchLike, $searchLike, $searchLike,
            $limit, $offset
        );
    } else {
        $sql = "SELECT trips.*, drivers.name AS driver_name 
                FROM trips 
                LEFT JOIN drivers ON trips.driver_id = drivers.id
                ORDER BY $sort $order
                LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $limit, $offset);
    }

    $stmt->execute();
    return $stmt->get_result();
}

function getTripById($conn, $id) {
    $stmt = $conn->prepare("SELECT * FROM trips WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function updateTrip($conn, $id, $driver_id, $status) {
    $stmt = $conn->prepare("UPDATE trips SET driver_id = ?, status = ? WHERE id = ?");
    $stmt->bind_param("isi", $driver_id, $status, $id);
    return $stmt->execute();
}

function deleteTrip($conn, $id) {
    $trip = getTripById($conn, $id);
    if (!$trip) return false;

    // Insert into deleted_trips
    $insert = $conn->prepare("INSERT INTO deleted_trips (
        id, first_name, last_name, phone, email, pickup, destination,
        trip_date, pickup_time, transfer_type, vehicle_type,
        payment_type, status, wp_order_id, deleted_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

    $wp_order_id = !empty($trip['wp_order_id']) ? (int)$trip['wp_order_id'] : null;

    $insert->bind_param(
        "issssssssssssi",
        $trip['id'],
        $trip['first_name'],
        $trip['last_name'],
        $trip['phone'],
        $trip['email'],
        $trip['pickup'],
        $trip['destination'],
        $trip['trip_date'],
        $trip['pickup_time'],
        $trip['transfer_type'],
        $trip['vehicle_type'],
        $trip['payment_type'],
        $trip['status'],
        $wp_order_id
    );

    if (!$insert->execute()) {
        error_log("Insert failed: " . $insert->error);
        return false;
    }

    $insert->close();

    // Delete trip
    $delete = $conn->prepare("DELETE FROM trips WHERE id = ?");
    $delete->bind_param("i", $id);
    $success = $delete->execute();
    $delete->close();

    // Optional: Delete WooCommerce order
    if (!empty($wp_order_id)) {
        $api_url = "https://brusselride.com/wp-json/wc/v3/orders/$wp_order_id";
        $consumer_key = 'ck_c931861c5580986ff81464a088538b3baf5dbfbe';
        $consumer_secret = 'cs_a846a520634439caeabf74cee0f807c848788146';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_USERPWD, "$consumer_key:$consumer_secret");
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For dev only
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($http_code >= 400) {
            error_log("❌ Woo delete failed: #$wp_order_id → HTTP $http_code → $response");
        }
        curl_close($ch);
    }

    return $success;
}

function soft_delete_trip($conn, $id) {
    $stmt = $conn->prepare("UPDATE trips SET is_archived = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}
?>
