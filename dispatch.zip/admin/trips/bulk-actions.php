<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

if (!current_user_can('manage_options')) {
    wp_die('Unauthorized.');
}

// Handle bulk delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_delete'])) {
    if (!empty($_POST['selected_trips']) && is_array($_POST['selected_trips'])) {
        foreach ($_POST['selected_trips'] as $trip_id) {
            $trip_id = intval($trip_id);
            wp_delete_post($trip_id, true); // permanently delete
        }
        wp_redirect($_SERVER['HTTP_REFERER']);
        exit;
    }
}

// Handle CSV export
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['export_csv'])) {
    if (!empty($_POST['selected_trips']) && is_array($_POST['selected_trips'])) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="trips_export.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Trip #', 'Date Pickup', 'Route', 'Payment', 'Vehicle', 'Status']);

        foreach ($_POST['selected_trips'] as $trip_id) {
            $trip_id = intval($trip_id);
            $order_number = get_post_meta($trip_id, 'mptbm_order_id', true);
            $pickup = get_post_meta($trip_id, 'mptbm_start_place', true);
            $destination = get_post_meta($trip_id, 'mptbm_end_place', true);
            $datetime = get_post_meta($trip_id, 'mptbm_date', true);
            $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime);
            $pickup_date = $dt ? $dt->format('Y-m-d') : '';
            $payment_type = get_post_meta($trip_id, 'mptbm_payment_method', true) ?: '-';
            $vehicle_id = get_post_meta($trip_id, 'mptbm_id', true);
            $vehicle_type = $vehicle_id ? get_the_title($vehicle_id) : '-';
            $transfer_type = get_post_meta($trip_id, 'mptbm_transfer_type', true);
            $transfer_label = ($transfer_type === 'round') ? 'Aller-retour' : 'Aller';
            $route = trim($pickup) . ' → ' . trim($destination) . " ($transfer_label)";
            $driver_id = get_post_meta($trip_id, 'driver_id', true);
            $status = $driver_id ? 'Course dispatchée' : 'Course non dispatchée';

            fputcsv($output, [
                $order_number,
                $pickup_date,
                $route,
                $payment_type,
                $vehicle_type,
                $status
            ]);
        }

        fclose($output);
        exit;
    }
}

wp_redirect($_SERVER['HTTP_REFERER']);
exit;
