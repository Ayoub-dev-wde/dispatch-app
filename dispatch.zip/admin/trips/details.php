<?php
// Chargement de WordPress si nécessaire
if (!function_exists('get_post_meta')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

// Validation de l'ID du trajet
$postID = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($postID <= 0 || get_post_type($postID) !== 'mptbm_booking') {
    wp_die('Trajet invalide.');
}

// Configuration de la page
$orderNumber = get_post_meta($postID, 'mptbm_order_id', true) ?: 'Inconnu';
$pageTitle = "";
$breadcrumbs = [
    ['label' => 'Réservations', 'url' => 'index.php'],
    ['label' => 'Détails du trajet n°' . esc_html($orderNumber)]
];
$showBackButton = true;
$isSubPage = true;

require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Récupération des données de la réservation
$meta = fn(string $k) => get_post_meta($postID, $k, true);

$billingName    = $meta('mptbm_billing_name');
$phone          = $meta('mptbm_billing_phone');
$email          = $meta('mptbm_billing_email');
$pickup         = $meta('mptbm_start_place');
$destination    = $meta('mptbm_end_place');
$datetime       = $meta('mptbm_date');
$transferType   = $meta('mptbm_taxi_return');
$vehicleID      = $meta('mptbm_id');
$vehicleTitle   = $vehicleID ? get_the_title($vehicleID) : '-';
$basePrice      = $meta('mptbm_base_price')     ?: '-';
$paymentMethod  = $meta('mptbm_payment_method') ?: '-';
$orderStatus    = $meta('mptbm_order_status')   ?: '-';

$driverID       = intval($meta('driver_id'));
$driverName     = 'Non assigné';
$dispatchStatus = 'Non dispatchée';

// Si un chauffeur est assigné, récupérer ses infos depuis la BDD
$driverPhone = $driverEmail = $driverStatus = $driverLanguage = $driverGender = $driverPhoto = '-';
$drivers_table = 'drivers';

if ($driverID) {
    global $wpdb;
    $driver = $wpdb->get_row($wpdb->prepare("SELECT * FROM $drivers_table WHERE id = %d", $driverID));
    if ($driver) {
        $driverName     = $driver->name ?: 'Inconnu';
        $dispatchStatus = 'Dispatchée';
        $driverPhone    = $driver->phone ?: '-';
        $driverEmail    = $driver->email ?: '-';
        $driverStatus   = $driver->status ?: '-';
        $driverLanguage = $driver->language ?: '-';
        $driverGender   = $driver->gender ?: '-';
        if (!empty($driver->photo_id)) {
            $driverPhoto = '/uploads/admin/' . $driver->photo_id;
        }
    }
}

// Formatage de la date
$tripDate = $pickupTime = '';
if ($datetime) {
    $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime)
        ?: DateTime::createFromFormat('Y-m-d', $datetime);
    if ($dt) {
        $tripDate   = $dt->format('Y-m-d');
        $pickupTime = $dt->format('H:i');
    }
}

// Libellé type de transfert
$transferLabel = $transferType === '2' ? 'Aller-retour'
              : ($transferType === '1' ? 'Aller' : htmlspecialchars($transferType));
?>

<!-- -------------- PAGE CONTENT -------------- -->
<div class="trip-details">
    <h2 class="trip-details__title"><?= esc_html($pageTitle) ?></h2>

    <table class="trip-details__table">
        <tbody>
            <tr><th>Trajet n°</th>         <td><?= esc_html($orderNumber) ?></td></tr>
            <tr><th>Client</th>            <td><?= esc_html($billingName) ?></td></tr>
            <tr><th>Téléphone</th>         <td><?= esc_html($phone) ?></td></tr>
            <tr><th>Email</th>             <td><?= esc_html($email) ?></td></tr>
            <tr><th>Départ</th>            <td><?= esc_html($pickup) ?></td></tr>
            <tr><th>Destination</th>       <td><?= esc_html($destination) ?></td></tr>
            <tr><th>Date</th>              <td><?= esc_html($tripDate) ?></td></tr>
            <tr><th>Heure</th>             <td><?= esc_html($pickupTime) ?></td></tr>
            <tr><th>Type</th>              <td><?= esc_html($transferLabel) ?></td></tr>
            <tr><th>Véhicule</th>          <td><?= esc_html($vehicleTitle) ?></td></tr>
            <tr><th>Prix (€)</th>          <td><?= esc_html($basePrice) ?></td></tr>
            <tr><th>Paiement</th>          <td><?= esc_html($paymentMethod) ?></td></tr>
            <tr><th>Statut commande</th>   <td><?= esc_html($orderStatus) ?></td></tr>
            <tr><th>Chauffeur</th>         <td><?= esc_html($driverName) ?></td></tr>
            <tr><th>Statut course</th>     <td><?= esc_html($dispatchStatus) ?></td></tr>

            <?php if ($driverID) : ?>
                <tr><th>Téléphone chauffeur</th> <td><?= esc_html($driverPhone) ?></td></tr>
                <tr><th>Email chauffeur</th>     <td><?= esc_html($driverEmail) ?></td></tr>
                <tr><th>Langue</th>              <td><?= esc_html($driverLanguage) ?></td></tr>
                <tr><th>Genre</th>               <td><?= esc_html($driverGender) ?></td></tr>
                <tr><th>Statut chauffeur</th>    <td><?= esc_html($driverStatus) ?></td></tr>
                <?php if ($driverPhoto !== '-') : ?>
                <tr><th>Photo</th>               <td><img src="<?= esc_url($driverPhoto) ?>" alt="Photo du chauffeur" height="80"></td></tr>
                <?php endif; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <p class="trip-details__back">
        <a href="index.php">← Retour à la liste des trajets</a>
    </p>
</div>

<!-- Styles -->
<link rel="stylesheet" href="/dispatch/shared/assets/css/trip-details.css">
