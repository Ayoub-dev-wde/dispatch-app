<?php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', true);
$pageTitle = "Réservations";
$breadcrumbs = [];

// Load WordPress
require_once dirname(__DIR__, 2) . '/../wp-load.php';
if (!function_exists('wc_get_order')) {
    exit('WooCommerce not active.');
}

// Global includes
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';




// Pagination
$posts_per_page = 10;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $posts_per_page;

// Date
$today = date('Y-m-d');

// Dashboard counts
$total_trips_today = (new WP_Query([
    'post_type' => 'mptbm_booking',
    'fields' => 'ids',
    'meta_query' => [
        ['key' => 'mptbm_date', 'value' => $today, 'compare' => 'LIKE'],
    ],
]))->found_posts;

$undispatched_trips = (new WP_Query([
    'post_type' => 'mptbm_booking',
    'fields' => 'ids',
    'meta_query' => [
        ['key' => 'driver_id', 'compare' => 'NOT EXISTS'],
    ],
]))->found_posts;

$upcoming_trips = (new WP_Query([
    'post_type' => 'mptbm_booking',
    'fields' => 'ids',
    'meta_query' => [
        ['key' => 'mptbm_date', 'value' => $today, 'compare' => '>', 'type' => 'DATE'],
    ],
]))->found_posts;

// Main query
$query = new WP_Query([
    'post_type' => 'mptbm_booking',
    'posts_per_page' => $posts_per_page,
    'offset' => $offset,
    'orderby' => 'date',
    'order' => 'DESC',
]);
$total_pages = ceil($query->found_posts / $posts_per_page);
?>

<!DOCTYPE html>
<html lang="fr">
<body>
<div class="trips-container">

    <!-- Dashboard Summary -->
    <div class="dashboard-summary">
        <div class="summary-item">Total trips today: <strong><?= esc_html($total_trips_today) ?></strong></div>
        <div class="summary-item">Undispatched trips: <strong><?= esc_html($undispatched_trips) ?></strong></div>
        <div class="summary-item">Upcoming trips: <strong><?= esc_html($upcoming_trips) ?></strong></div>
    </div>

    <?php if ($query->have_posts()): ?>
        <div class="trips-table-wrapper">
            <input type="text" id="searchInput" placeholder="Rechercher un trajet..." class="trip-search-input" />

            <table class="trips-table">
                <thead>
                    <tr>
                        <th>Trip #</th>
                        <th>Date pickup</th>
                        <th>Route</th>
                        <th>Payment</th>
                        <th>Vehicle</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($query->have_posts()): $query->the_post();
                        $post_id = get_the_ID();
                        $order_number = get_post_meta($post_id, 'mptbm_order_id', true);
                        $pickup = get_post_meta($post_id, 'mptbm_start_place', true);
                        $destination = get_post_meta($post_id, 'mptbm_end_place', true);
                        $datetime = get_post_meta($post_id, 'mptbm_date', true);
                        $payment_type = get_post_meta($post_id, 'mptbm_payment_method', true) ?: '-';
                        $vehicle_id = get_post_meta($post_id, 'mptbm_id', true);
                        $vehicle_type = $vehicle_id ? get_the_title($vehicle_id) : '-';
                        $dt = DateTime::createFromFormat('Y-m-d H:i', $datetime) ?: DateTime::createFromFormat('Y-m-d', $datetime);
                        $pickup_date = $dt ? $dt->format('Y-m-d') : '';
                        $transfer_type = get_post_meta($post_id, 'mptbm_transfer_type', true);
                        $transfer_label = ($transfer_type === 'round') ? 'Aller-retour' : 'Aller';
                        $route = trim($pickup) . ' → ' . trim($destination) . ' (' . $transfer_label . ')';
                        $driver_id = get_post_meta($post_id, 'driver_id', true);
                        $trip_status = $driver_id ? 'Course dispatchée' : 'Course non dispatchée';
                        $nonce = wp_create_nonce('delete_trip_' . $post_id);
                    ?>
                    <tr>
                        <td><?= esc_html($order_number) ?></td>
                        <td><?= esc_html($pickup_date) ?></td>
                        <td><?= esc_html($route) ?></td>
                        <td><?= esc_html($payment_type) ?></td>
                        <td><?= esc_html($vehicle_type) ?></td>
                        <td><?= esc_html($trip_status) ?></td>
                        <td>
                            <a href="details.php?id=<?= $post_id ?>">Voir</a> |
                            <a href="edit.php?id=<?= $post_id ?>">Modifier</a> |
                            <a href="delete.php?id=<?= $post_id ?>&nonce=<?= $nonce ?>" onclick="return confirm('Supprimer ce trajet ?');">Supprimer</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="pagination">
            <?php if ($current_page > 1): ?>
                <a href="?paged=<?= $current_page - 1 ?>">&laquo; Prev</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i == $current_page): ?>
                    <span class="current"><?= $i ?></span>
                <?php else: ?>
                    <a href="?paged=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($current_page < $total_pages): ?>
                <a href="?paged=<?= $current_page + 1 ?>">Next &raquo;</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <p class="no-results">Aucun trajet trouvé.</p>
    <?php endif; wp_reset_postdata(); ?>
</div>

<script src="/dispatch/shared/assets/js/trips.js"></script>
</body>
</html>
