<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();


require_once __DIR__ . '/../shared/config.php';
if (isset($_SESSION['user_id'])) {
    header('Location: /dispatch/admin/dashboard.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $remember_me = isset($_POST['remember']);

    if (empty($username) || empty($password)) {
        $error = 'Veuillez remplir tous les champs.';
    } else {
        $stmt = $conn->prepare("SELECT id, password FROM dispatch_user WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $user_id;

                if ($remember_me) {
                    $token = bin2hex(random_bytes(32));
                    setcookie('remember_me', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
                    $stmt = $conn->prepare("UPDATE dispatch_user SET remember_token = ? WHERE id = ?");
                    $stmt->bind_param("si", password_hash($token, PASSWORD_BCRYPT), $user_id);
                    $stmt->execute();
                }

                $redirect_url = $_SESSION['redirect_url'] ?? '/dispatch/admin/dashboard.php';
                header('Location: ' . $redirect_url);
                exit();
            } else {
                $error = 'Mot de passe incorrect.';
            }
        } else {
            $error = 'Utilisateur introuvable.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion | Dispatch Taxi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/dispatch/shared/assets/css/login-modern.css">
</head>
<body>
  <div class="login-container">
    <div class="login-left">
      <img src="/dispatch/shared/assets/images/logo.png" alt="Logo" class="logo">
      <h2>Connexion</h2>
      <p>Connectez-vous pour accéder au système de dispatch.</p>

      <?php if (!empty($error)): ?>
        <div class="error-box"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="post">
        <input type="text" name="username" placeholder="Nom d'utilisateur" required>
        <input type="password" name="password" placeholder="Mot de passe" required>
        <div class="form-row">
          <label><input type="checkbox" name="remember"> Se souvenir de moi</label>
        </div>
        <button type="submit">Se connecter</button>
      </form>
              <p class="back-link"><a href="/dispatch/index.php">← Retour à l'accueil</a></p>

    </div>
    <div class="login-right">
      <img src="/dispatch/shared/assets/images/login.webp" alt="Taxi Background">
      
    </div>
  </div>
</body>
</html>