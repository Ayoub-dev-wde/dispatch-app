<?php
ob_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle = "Liste des Chauffeurs";
$breadcrumbs = [];
$showBackButton = false;

require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit();
}

/* ─────────────────────────────────────────────────────────────
   Handle delete
   ────────────────────────────────────────────────────────────*/
if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    if ($deleteId > 0) {
        $stmt = $conn->prepare("DELETE FROM drivers WHERE id = ?");
        $stmt->bind_param("i", $deleteId);
        $stmt->execute();
        $stmt->close();
        header("Location: index.php?deleted=1");
        exit();
    }
}

/* ─────────────────────────────────────────────────────────────
   Fetch all drivers with vehicle info
   ────────────────────────────────────────────────────────────*/
$sql = "
    SELECT 
        d.*, 
        v.make AS vehicle_make,
        v.model AS vehicle_model
    FROM drivers d
    LEFT JOIN vehicles v ON d.vehicle_id = v.id
    ORDER BY d.id DESC
";
$result = $conn->query($sql);
?>

<div class="container">
    <h1 class="page-title"><?= htmlspecialchars($pageTitle) ?></h1>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success">✅ Chauffeur supprimé avec succès.</div>
    <?php endif; ?>

    <a class="btn btn-primary" href="add.php">➕ Ajouter un chauffeur</a>
    <a class="btn btn-primary" href="/dispatch/admin/drivers/registration/pending.php">Chauffeurs en attente</a>

    <table class="drivers-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Véhicule</th>
                <th>Expiration Permis</th>
                <th>Contacts</th>
                <th>Créé</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($driver = $result->fetch_assoc()): ?>
                    <?php
                        $photoPath = __DIR__ . '/../../uploads/admin/drivers/' . $driver['photo_id'];
                        $hasPhoto  = !empty($driver['photo_id']) && file_exists($photoPath);
                        $vehicle   = (!empty($driver['vehicle_make']) || !empty($driver['vehicle_model']))
                            ? htmlspecialchars(trim($driver['vehicle_make'] . ' ' . $driver['vehicle_model']))
                            : '<em>Aucun</em>';
                    ?>
                    <tr class="driver-row">
                        <td data-label="ID"><?= htmlspecialchars($driver['id']) ?></td>

                        <td data-label="Nom" class="driver-name">
                            <?php if ($hasPhoto): ?>
                                <img class="driver-photo" src="/dispatch/uploads/admin/profile_photos/<?= rawurlencode($driver['photo_id']) ?>" alt="Photo">
                            <?php else: ?>
                                <div class="no-photo">?</div>
                            <?php endif; ?>
                            <?= htmlspecialchars($driver['name']) ?>
                        </td>

                        <td data-label="Véhicule"><?= $vehicle ?></td>

                        <td data-label="Expiration Permis">
                            <?= htmlspecialchars($driver['license_expires']) ?: '<em>Non défini</em>' ?>
                        </td>

                        <td data-label="Contacts" class="contacts-column">
                            📞 <a href="tel:<?= htmlspecialchars($driver['phone']) ?>"><?= htmlspecialchars($driver['phone']) ?></a><br>
                            ✉️ <a href="mailto:<?= htmlspecialchars($driver['email']) ?>"><?= htmlspecialchars($driver['email']) ?></a><br>
                            <?php if (!empty($driver['whatsapp'])): ?>
                                📱 <a href="https://wa.me/<?= preg_replace('/\D+/', '', $driver['whatsapp']) ?>" target="_blank" rel="noopener noreferrer">WhatsApp</a>
                            <?php endif; ?>
                        </td>

                        <td data-label="Créé"><?= htmlspecialchars($driver['created_at']) ?></td>

                        <td data-label="Actions" class="actions-column">
    <a class="btn btn-info" href="more_info.php?id=<?= urlencode($driver['id']) ?>">Voir plus</a>
    &nbsp;|&nbsp;
    <a class="btn btn-warning" href="edit.php?id=<?= urlencode($driver['id']) ?>">Modifier</a>
    &nbsp;|&nbsp;
    <a class="btn btn-danger btn-delete" href="index.php?delete=<?= urlencode($driver['id']) ?>" onclick="return confirm('Supprimer ce chauffeur ?');">Supprimer</a>
</td>

                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" class="no-drivers">Aucun chauffeur trouvé.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<link href="/dispatch/shared/assets/css/drivers.css" rel="stylesheet">
<script src="/dispatch/shared/assets/js/subheader.js" defer></script>

<?php require_once __DIR__ . '/../../shared/inc/admin/footer.php';
ob_end_flush();
