<?php
require_once __DIR__ . '/../../shared/inc/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit();
}

function showError($message) {
    echo "<!DOCTYPE html><html><head><title>Erreur</title></head><body>";
    echo "<p style='color:red; font-weight:bold;'>$message</p>";
    echo "</body></html>";
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    showError("ID invalide.");
}

$id = (int)$_GET['id'];

// Check if driver exists
$stmt = $conn->prepare("SELECT id FROM drivers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $stmt->close();
    showError("Chauffeur introuvable.");
}
$stmt->close();

// Delete driver
$stmt = $conn->prepare("DELETE FROM drivers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

// Redirect
header("Location: index.php");
exit();
