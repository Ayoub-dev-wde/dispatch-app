<?php
ob_start();
$pageTitle = "Modifier le Chauffeur";
$breadcrumbs = [];
$showBackButton = true;
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit();
}

$driver_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$driver_id) {
    header("Location: index.php");
    exit();
}

// Récupérer les véhicules
$vehicles = [];
$res = $conn->query("SELECT id, make, model FROM vehicles ORDER BY make ASC");
while ($row = $res->fetch_assoc()) {
    $vehicles[] = $row;
}

// Récupérer données chauffeur
$stmt = $conn->prepare("SELECT * FROM drivers WHERE id = ?");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$result = $stmt->get_result();
$driver = $result->fetch_assoc();
$stmt->close();

if (!$driver) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $whatsapp = trim($_POST['whatsapp']);
    $gender = $_POST['gender'] ?? null;
    $language = $_POST['language'] ?? 'Français';
    $vehicle_id = $_POST['vehicle_id'] ?: null;
    $license_info = trim($_POST['license_info']);
    $license_expires = $_POST['license_expires'] ?: null;
    $pco_license = trim($_POST['pco_license']);
    $pco_license_expires = $_POST['pco_license_expires'] ?: null;
    $comment = trim($_POST['comment']);
    $new_password = $_POST['password'] ?? '';
    $photo_filename = $driver['photo_id'];

    // Gérer la photo
    if (!empty($_FILES['photo']['name'])) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $photo_filename = uniqid('driver_', true) . '.' . $ext;
        $destination = __DIR__ . '/../../uploads/admin/drivers/' . $photo_filename;
        move_uploaded_file($_FILES['photo']['tmp_name'], $destination);

        if (!empty($driver['photo_id'])) {
            $oldPath = __DIR__ . '/../../uploads/admin/drivers/' . $driver['photo_id'];
            if (file_exists($oldPath)) unlink($oldPath);
        }
    }

    if (!empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            UPDATE drivers SET
                name = ?, phone = ?, email = ?, whatsapp = ?, gender = ?, language = ?, vehicle_id = ?, 
                license_info = ?, license_expires = ?, pco_license = ?, pco_license_expires = ?, 
                comment = ?, photo_id = ?, password = ?
            WHERE id = ?
        ");
        $stmt->bind_param(
            "ssssssisssssssi",
            $name, $phone, $email, $whatsapp, $gender, $language, $vehicle_id,
            $license_info, $license_expires, $pco_license, $pco_license_expires,
            $comment, $photo_filename, $hashed_password, $driver_id
        );
    } else {
        $stmt = $conn->prepare("
            UPDATE drivers SET
                name = ?, phone = ?, email = ?, whatsapp = ?, gender = ?, language = ?, vehicle_id = ?, 
                license_info = ?, license_expires = ?, pco_license = ?, pco_license_expires = ?, 
                comment = ?, photo_id = ?
            WHERE id = ?
        ");
        $stmt->bind_param(
            "ssssssisssssssi",
            $name, $phone, $email, $whatsapp, $gender, $language, $vehicle_id,
            $license_info, $license_expires, $pco_license, $pco_license_expires,
            $comment, $photo_filename, $driver_id
        );
    }

    $stmt->execute();
    $stmt->close();

    header("Location: index.php");
    exit();
}
?>

<div class="container">
    <h1 class="page-title"><?= htmlspecialchars($pageTitle) ?></h1>

    <form method="post" enctype="multipart/form-data" class="driver-form">

        <div class="form-group">
            <label>📸 Ajouter une photo</label><br>
            <?php if (!empty($driver['photo_id'])): ?>
                <img src="/dispatch/uploads/admin/drivers/<?= htmlspecialchars($driver['photo_id']) ?>" width="100">
            <?php endif; ?>
            <input type="file" name="photo" accept="image/*">
        </div>

        <div class="form-group">
            <label>Nom:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($driver['name']) ?>" required>
        </div>

        <div class="form-group">
            <label>Téléphone:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($driver['phone']) ?>" required>
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($driver['email']) ?>">
        </div>

        <div class="form-group">
            <label>WhatsApp:</label>
            <input type="text" name="whatsapp" value="<?= htmlspecialchars($driver['whatsapp']) ?>">
        </div>

        <div class="form-group">
            <label>Sexe:</label>
            <select name="gender">
                <option value="">--</option>
                <option value="male" <?= $driver['gender'] === 'male' ? 'selected' : '' ?>>Homme</option>
                <option value="female" <?= $driver['gender'] === 'female' ? 'selected' : '' ?>>Femme</option>
            </select>
        </div>

        <div class="form-group">
            <label>Langue:</label>
            <select name="language">
                <option value="Français" <?= $driver['language'] === 'Français' ? 'selected' : '' ?>>Français</option>
                <option value="Anglais" <?= $driver['language'] === 'Anglais' ? 'selected' : '' ?>>Anglais</option>
            </select>
        </div>

        <div class="form-group">
            <label>Véhicule assigné :</label>
            <select name="vehicle_id">
                <option value="">-- Aucun --</option>
                <?php foreach ($vehicles as $v): ?>
                    <option value="<?= $v['id'] ?>" <?= ($driver['vehicle_id'] == $v['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($v['make'] . ' ' . $v['model']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Infos Permis:</label>
            <input type="text" name="license_info" value="<?= htmlspecialchars($driver['license_info']) ?>">
        </div>

        <div class="form-group">
            <label>Expire le:</label>
            <input type="date" name="license_expires" value="<?= htmlspecialchars($driver['license_expires']) ?>">
        </div>

        <div class="form-group">
            <label>PCO License:</label>
            <input type="text" name="pco_license" value="<?= htmlspecialchars($driver['pco_license']) ?>">
        </div>

        <div class="form-group">
            <label>Expire PCO:</label>
            <input type="date" name="pco_license_expires" value="<?= htmlspecialchars($driver['pco_license_expires']) ?>">
        </div>

        <div class="form-group">
            <label>Commentaire:</label>
            <textarea name="comment" rows="3"><?= htmlspecialchars($driver['comment']) ?></textarea>
        </div>

        <div class="form-group">
            <label>🔐 Nouveau mot de passe (laisser vide si inchangé):</label>
            <input type="password" name="password">
        </div>

        <div class="form-actions">
            <a class="btn btn-secondary" href="index.php">⬅️ Retour</a>
            <button class="btn btn-primary" type="submit">💾 Enregistrer les modifications</button>
        </div>

    </form>
</div>

<link href="/dispatch/shared/assets/css/drivers.css" rel="stylesheet">
<script src="/dispatch/shared/assets/js/subheader.js" defer></script>

<?php require_once __DIR__ . '/../../shared/inc/footer.php';
ob_end_flush(); ?>
