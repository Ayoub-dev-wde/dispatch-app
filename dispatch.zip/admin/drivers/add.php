<?php
ob_start();
$pageTitle = "Ajouter un nouveau Chauffeur";
$breadcrumbs = [];
$showBackButton = true;
require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

// Rediriger si non connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit();
}

// Récupérer les véhicules
$vehicles = [];
$res = $conn->query("SELECT id, make, model FROM vehicles ORDER BY make ASC");
while ($row = $res->fetch_assoc()) {
    $vehicles[] = $row;
}

$errors = [];

// Si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $whatsapp = trim($_POST['whatsapp']);
    $gender = $_POST['gender'] ?? null;
    $language = $_POST['language'] ?? 'Français';
    $vehicle_id = $_POST['vehicle_id'] ?: null;
    $license_info = trim($_POST['license_info']);
    $license_expires = $_POST['license_expires'] ?: null;
    $pco_license = trim($_POST['pco_license']);
    $pco_license_expires = $_POST['pco_license_expires'] ?: null;
    $comment = trim($_POST['comment']);
    $password = $_POST['password'] ?? '';
    $photo_filename = null;

    // Validation
    if (empty($name)) $errors[] = "Le nom est obligatoire.";
    if (empty($phone)) $errors[] = "Le téléphone est obligatoire.";
    if (empty($email)) $errors[] = "L'email est obligatoire.";
    if (empty($vehicle_id)) $errors[] = "Veuillez assigner un véhicule.";
    if (empty($license_expires)) $errors[] = "La date d'expiration du permis est obligatoire.";
    if (empty($password)) $errors[] = "Le mot de passe est obligatoire.";

    // Gérer l'upload photo
    if (!empty($_FILES['photo']['name'])) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $photo_filename = uniqid('driver_', true) . '.' . $ext;
        $destination = __DIR__ . '/../../uploads/admin/drivers/' . $photo_filename;
        move_uploaded_file($_FILES['photo']['tmp_name'], $destination);
    }

    if (empty($errors)) {
        // Hacher le mot de passe
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            INSERT INTO drivers 
            (name, phone, email, whatsapp, gender, language, vehicle_id, 
             license_info, license_expires, pco_license, pco_license_expires, 
             comment, photo_id, password, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'actif', NOW())
        ");
        $stmt->bind_param(
            "ssssssisssssss",
            $name, $phone, $email, $whatsapp, $gender, $language, $vehicle_id,
            $license_info, $license_expires, $pco_license, $pco_license_expires,
            $comment, $photo_filename, $hashedPassword
        );
        $stmt->execute();
        $stmt->close();

        header("Location: index.php");
        exit();
    }
}
?>

<div class="container">
    <h1 class="page-title"><?= htmlspecialchars($pageTitle) ?></h1>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="driver-form">

        <div class="form-group">
            <label>📸 Ajouter une photo</label><br>
            <input type="file" name="photo" accept="image/*">
        </div>

        <div class="form-group">
            <label>Nom:</label>
            <input type="text" name="name" required>
        </div>

        <div class="form-group">
            <label>Téléphone:</label>
            <input type="text" name="phone" required>
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" required>
        </div>

        <div class="form-group">
            <label>Mot de passe:</label>
            <input type="password" name="password" required>
        </div>

        <div class="form-group">
            <label>WhatsApp:</label>
            <input type="text" name="whatsapp">
        </div>

        <div class="form-group">
            <label>Sexe:</label>
            <select name="gender">
                <option value="">--</option>
                <option value="male">Homme</option>
                <option value="female">Femme</option>
            </select>
        </div>

        <div class="form-group">
            <label>Langue:</label>
            <select name="language">
                <option value="Français">Français</option>
                <option value="Anglais">Anglais</option>
            </select>
        </div>

        <div class="form-group">
            <label>Véhicule assigné :</label>
            <select name="vehicle_id" required>
                <option value="">-- Aucun --</option>
                <?php foreach ($vehicles as $v): ?>
                    <option value="<?= $v['id'] ?>">
                        <?= htmlspecialchars($v['make'] . ' ' . $v['model']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Infos Permis:</label>
            <input type="text" name="license_info">
        </div>

        <div class="form-group">
            <label>Expire le:</label>
            <input type="date" name="license_expires" required>
        </div>

        <div class="form-group">
            <label>PCO License:</label>
            <input type="text" name="pco_license">
        </div>

        <div class="form-group">
            <label>Expire PCO:</label>
            <input type="date" name="pco_license_expires">
        </div>

        <div class="form-group">
            <label>Commentaire:</label>
            <textarea name="comment" rows="3"></textarea>
        </div>

        <div class="form-actions">
            <a class="btn btn-secondary" href="index.php">⬅️ Retour</a>
            <button class="btn btn-success" type="submit">✅ Enregistrer</button>
        </div>

    </form>
</div>

<link href="/dispatch/shared/assets/css/drivers.css" rel="stylesheet">
<script src="/dispatch/shared/assets/js/subheader.js" defer></script>

<?php require_once __DIR__ . '/../../shared/inc/footer.php';
ob_end_flush(); ?>
