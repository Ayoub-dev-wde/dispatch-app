<?php
$pageTitle = "Détails du Chauffeur";
$breadcrumbs = [];
$showBackButton = true;

require_once __DIR__ . '/../../shared/inc/bootstrap_admin.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /dispatch/admin/login.php");
    exit();
}

$driver_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$driver_id) {
    header("Location: index.php");
    exit();
}

// Requête avec jointure véhicule
$stmt = $conn->prepare("
    SELECT d.*, v.make AS vehicle_make, v.model AS vehicle_model 
    FROM drivers d 
    LEFT JOIN vehicles v ON d.vehicle_id = v.id 
    WHERE d.id = ?
");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$result = $stmt->get_result();
$driver = $result->fetch_assoc();
$stmt->close();

if (!$driver) {
    header("Location: index.php");
    exit();
}

$photoURL = !empty($driver['photo_id']) ? "/dispatch/uploads/admin/drivers/" . rawurlencode($driver['photo_id']) : null;
?>

<div class="container">
    <h1 class="page-title">Détails du Chauffeur</h1>

    <div class="driver-detail">
        <?php if ($photoURL): ?>
            <img src="<?= $photoURL ?>" alt="Photo" class="driver-photo-large">
        <?php else: ?>
            <div class="no-photo-large">Aucune photo</div>
        <?php endif; ?>

        <ul class="driver-info-list">
            <li><strong>Nom:</strong> <?= htmlspecialchars($driver['name']) ?></li>
            <li><strong>Téléphone:</strong> <a href="tel:<?= htmlspecialchars($driver['phone']) ?>"><?= htmlspecialchars($driver['phone']) ?></a></li>
            <li><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($driver['email']) ?>"><?= htmlspecialchars($driver['email']) ?></a></li>
            <li><strong>WhatsApp:</strong> <?= htmlspecialchars($driver['whatsapp']) ?: '<em>Non fourni</em>' ?></li>
            <li><strong>Sexe:</strong> <?= htmlspecialchars($driver['gender']) ?: '<em>Non défini</em>' ?></li>
            <li><strong>Langue:</strong> <?= htmlspecialchars($driver['language']) ?></li>
            <li><strong>Véhicule assigné:</strong> 
                <?= ($driver['vehicle_make'] || $driver['vehicle_model']) 
                    ? htmlspecialchars(trim($driver['vehicle_make'] . ' ' . $driver['vehicle_model']))
                    : '<em>Aucun</em>' ?>
            </li>
            <li><strong>Infos Permis:</strong> <?= htmlspecialchars($driver['license_info']) ?></li>
            <li><strong>Expiration Permis:</strong> <?= htmlspecialchars($driver['license_expires']) ?: '<em>Non défini</em>' ?></li>
            <li><strong>PCO License:</strong> <?= htmlspecialchars($driver['pco_license']) ?></li>
            <li><strong>Expiration PCO:</strong> <?= htmlspecialchars($driver['pco_license_expires']) ?: '<em>Non défini</em>' ?></li>
            <li><strong>Commentaire:</strong><br><?= nl2br(htmlspecialchars($driver['comment'])) ?></li>
            <li><strong>Créé le:</strong> <?= htmlspecialchars($driver['created_at']) ?></li>
        </ul>

        <div class="form-actions">
            <a class="btn btn-secondary" href="index.php">⬅️ Retour</a>
            <a class="btn btn-primary" href="edit.php?id=<?= urlencode($driver['id']) ?>">✏️ Modifier</a>
        </div>
    </div>
</div>

<link href="/dispatch/shared/assets/css/drivers.css" rel="stylesheet">
<script src="/dispatch/shared/assets/js/subheader.js" defer></script>

<?php require_once __DIR__ . '/../../shared/inc/footer.php'; ?>
