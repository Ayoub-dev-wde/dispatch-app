<?php
ob_start();
session_start();
require_once __DIR__ . '/../../../shared/inc/db_connect.php';
require_once __DIR__ . '/../../../shared/inc/bootstrap_admin.php';

$query = "SELECT d.id, d.name, d.phone, d.email, d.created_at, v.make, v.model, v.license_plate
          FROM drivers d
          LEFT JOIN vehicles v ON d.vehicle_id = v.id
          WHERE d.status = 'en_attente'";
$result = $conn->query($query);
?>

<h2>Chauffeurs en attente</h2>

<?php if (isset($_SESSION['success'])): ?>
    <p style="color: green;"><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
<?php endif; ?>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Téléphone</th>
            <th>Email</th>
            <th>Véhicule</th>
            <th>Date de soumission</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['make']) ?> <?= htmlspecialchars($row['model']) ?> (<?= htmlspecialchars($row['license_plate']) ?>)</td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
                <a href="details.php?id=<?= $row['id'] ?>">👁 Voir</a> |
                <a href="approve.php?id=<?= $row['id'] ?>" style="color: green;">✅ Accepter</a> |
                <a href="reject.php?id=<?= $row['id'] ?>" style="color: red;" onclick="return confirm('Êtes-vous sûr de vouloir rejeter ?')">❌ Rejeter</a>
            </td>
        </tr>
        <?php endwhile; ?>
        <p><a href="/dispatch/admin/drivers/index.php">⬅ Retour à la liste des véhicules</a></p>
    </tbody>
</table>
