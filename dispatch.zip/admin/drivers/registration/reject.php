<?php
ob_start();
session_start();
require_once __DIR__ . '/../../../shared/inc/db_connect.php';
require_once __DIR__ . '/../../../shared/inc/bootstrap_admin.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID invalide.");
}

$driver_id = intval($_GET['id']);

// 1. Fetch vehicle_id for this driver
$stmt = $conn->prepare("SELECT vehicle_id FROM drivers WHERE id = ?");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Chauffeur introuvable.");
}

$vehicle_id = $result->fetch_assoc()['vehicle_id'];
$stmt->close();

// 2. Reject driver
$stmt = $conn->prepare("UPDATE drivers SET status = 'rejeté' WHERE id = ?");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$stmt->close();

// 3. Reject vehicle
if ($vehicle_id) {
    $stmt = $conn->prepare("UPDATE vehicles SET status = 'rejeté' WHERE id = ?");
    $stmt->bind_param("i", $vehicle_id);
    $stmt->execute();
    $stmt->close();
}

$_SESSION['success'] = "Chauffeur rejeté avec succès.";
header("Location: pending.php");
exit();
