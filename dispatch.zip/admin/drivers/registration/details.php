<?php
ob_start();
session_start();
require_once __DIR__ . '/../../../shared/inc/db_connect.php';
require_once __DIR__ . '/../../../shared/inc/bootstrap_admin.php';
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID invalide.");
}

$driver_id = intval($_GET['id']);

// Fetch driver and vehicle data
$stmt = $conn->prepare("
    SELECT d.*, v.make, v.model, v.year, v.license_plate, v.color, v.comment AS vehicle_comment, v.photo AS vehicle_photo
    FROM drivers d
    LEFT JOIN vehicles v ON d.vehicle_id = v.id
    WHERE d.id = ?
");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Chauffeur introuvable.");
}

$data = $result->fetch_assoc();
$stmt->close();
?>

<h2>Détails du Chauffeur</h2>

<p><strong>Nom:</strong> <?= htmlspecialchars($data['name']) ?></p>
<p><strong>Téléphone:</strong> <?= htmlspecialchars($data['phone']) ?></p>
<p><strong>Email:</strong> <?= htmlspecialchars($data['email']) ?></p>
<p><strong>WhatsApp:</strong> <?= htmlspecialchars($data['whatsapp']) ?></p>
<p><strong>Genre:</strong> <?= htmlspecialchars($data['gender']) ?></p>
<p><strong>Langue:</strong> <?= htmlspecialchars($data['language']) ?></p>
<p><strong>Permis:</strong> <?= htmlspecialchars($data['license_info']) ?></p>
<p><strong>Expiration du permis:</strong> <?= htmlspecialchars($data['license_expires']) ?></p>
<p><strong>Licence PCO:</strong> <?= htmlspecialchars($data['pco_license']) ?></p>
<p><strong>Expiration PCO:</strong> <?= htmlspecialchars($data['pco_license_expires']) ?></p>
<p><strong>Commentaire:</strong> <?= nl2br(htmlspecialchars($data['comment'])) ?></p>
<?php if ($data['photo']): ?>
    <p><strong>Photo du chauffeur:</strong><br>
        <img src="../uploads/admin/drivers/<?= htmlspecialchars($data['photo']) ?>" width="200">
    </p>
<?php endif; ?>

<hr>

<h2>Détails du Véhicule</h2>

<p><strong>Marque:</strong> <?= htmlspecialchars($data['make']) ?></p>
<p><strong>Modèle:</strong> <?= htmlspecialchars($data['model']) ?></p>
<p><strong>Année:</strong> <?= htmlspecialchars($data['year']) ?></p>
<p><strong>Immatriculation:</strong> <?= htmlspecialchars($data['license_plate']) ?></p>
<p><strong>Couleur:</strong> <?= htmlspecialchars($data['color']) ?></p>
<p><strong>Commentaire véhicule:</strong> <?= nl2br(htmlspecialchars($data['vehicle_comment'])) ?></p>
<?php if ($data['vehicle_photo']): ?>
    <p><strong>Photo du véhicule:</strong><br>
        <img src="../<?= htmlspecialchars($data['vehicle_photo']) ?>" width="200">
    </p>
<?php endif; ?>

<p><a href="pending.php">← Retour à la liste</a></p>
