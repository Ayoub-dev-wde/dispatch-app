<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;
$table = $wpdb->prefix . 'dispatch_notifications';

if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
    echo json_encode(['error' => 'Table introuvable']);
    exit;
}

$notifications = $wpdb->get_results(
    "SELECT id, message, created_at, is_read FROM $table ORDER BY created_at DESC LIMIT 10",
    ARRAY_A
);

if ($notifications === null) {
    echo json_encode(['error' => 'Erreur lors de la récupération']);
} else {
    echo json_encode($notifications);
}
exit;
