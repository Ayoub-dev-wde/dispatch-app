<?php
// chart_dispatch.php

define('WP_USE_THEMES', false);
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json');

global $wpdb;

$start_date = date('Y-m-d', strtotime('-6 days')) . ' 00:00:00';
$end_date = date('Y-m-d') . ' 23:59:59';

$labels = [];
$data = [];
for ($i = 6; $i >= 0; $i--) {
    $labels[] = date('Y-m-d', strtotime("-$i days"));
    $data[] = 0;
}

$sql = "
SELECT DATE(pm_date.meta_value) AS date, COUNT(*) AS total
FROM {$wpdb->posts} p
INNER JOIN {$wpdb->postmeta} pm_date ON p.ID = pm_date.post_id AND pm_date.meta_key = 'mptbm_date'
INNER JOIN {$wpdb->postmeta} pm_driver ON p.ID = pm_driver.post_id AND pm_driver.meta_key = 'mptbm_driver_name'
WHERE p.post_type = 'mptbm_booking'
  AND p.post_status = 'publish'
  AND pm_date.meta_value BETWEEN %s AND %s
  AND pm_driver.meta_value != ''
  AND pm_driver.meta_value != 'Non assigné'
GROUP BY DATE(pm_date.meta_value)
";

$query = $wpdb->prepare($sql, $start_date, $end_date);
$results = $wpdb->get_results($query);

$dateIndex = array_flip($labels);

foreach ($results as $row) {
    if (isset($dateIndex[$row->date])) {
        $data[$dateIndex[$row->date]] = intval($row->total);
    }
}

echo json_encode([
    'labels' => $labels,
    'data' => $data,
]);

exit();
