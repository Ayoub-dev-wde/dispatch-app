<?php
// chart_revenue.php

define('WP_USE_THEMES', false);
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json');

global $wpdb;

$start_date = date('Y-m-d', strtotime('-6 days')) . ' 00:00:00';
$end_date = date('Y-m-d') . ' 23:59:59';

$labels = [];
$data = [];
for ($i = 6; $i >= 0; $i--) {
    $labels[] = date('Y-m-d', strtotime("-$i days"));
    $data[] = 0;
}

$sql = "
SELECT DATE(pm_date.meta_value) AS date, SUM(CAST(pm_price.meta_value AS DECIMAL(10,2))) AS total
FROM {$wpdb->posts} p
INNER JOIN {$wpdb->postmeta} pm_date ON p.ID = pm_date.post_id AND pm_date.meta_key = 'mptbm_date'
INNER JOIN {$wpdb->postmeta} pm_price ON p.ID = pm_price.post_id AND pm_price.meta_key = 'mptbm_base_price'
WHERE p.post_type = 'mptbm_booking'
  AND p.post_status = 'publish'
  AND pm_date.meta_value BETWEEN %s AND %s
GROUP BY DATE(pm_date.meta_value)
";

$query = $wpdb->prepare($sql, $start_date, $end_date);
$results = $wpdb->get_results($query);

$dateIndex = array_flip($labels);

foreach ($results as $row) {
    if (isset($dateIndex[$row->date])) {
        $data[$dateIndex[$row->date]] = floatval($row->total);
    }
}

echo json_encode([
    'labels' => $labels,
    'data' => $data,
]);

exit();
