<?php
// chart_cod.php

define('WP_USE_THEMES', false);
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json');

global $wpdb;

$start_date = date('Y-m-d', strtotime('-6 days')) . ' 00:00:00';
$end_date = date('Y-m-d') . ' 23:59:59';

$labels = [];
$data = [];
for ($i = 6; $i >= 0; $i--) {
    $labels[] = date('Y-m-d', strtotime("-$i days"));
    $data[] = 0;
}

$sql = "
    SELECT DATE(created_at) AS date, SUM(payment_cod) AS total
    FROM account_transactions
    WHERE created_at BETWEEN %s AND %s
    GROUP BY DATE(created_at)
";

$query = $wpdb->prepare($sql, $start_date, $end_date);
$results = $wpdb->get_results($query);

$dateIndex = array_flip($labels);

foreach ($results as $row) {
    if (isset($dateIndex[$row->date])) {
        $data[$dateIndex[$row->date]] = floatval($row->total);
    }
}

echo json_encode([
    'labels' => $labels,
    'data' => $data,
]);

exit();
