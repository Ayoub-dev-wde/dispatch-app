<?php
// chart_drivers.php

define('WP_USE_THEMES', false);
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json');

global $wpdb;

$start_date = date('Y-m-d', strtotime('-6 days')) . ' 00:00:00';
$end_date = date('Y-m-d') . ' 23:59:59';

// Get all active drivers
$drivers = $wpdb->get_results("SELECT name FROM drivers WHERE status='disponible'");

$driver_names = [];
$driver_counts = [];

foreach ($drivers as $driver) {
    $driver_names[] = $driver->name;
    $driver_counts[$driver->name] = 0;
}

// Count trips per driver in last 7 days
$sql = "
SELECT pm_driver.meta_value AS driver_name, COUNT(*) AS trip_count
FROM {$wpdb->posts} p
INNER JOIN {$wpdb->postmeta} pm_date ON p.ID = pm_date.post_id AND pm_date.meta_key = 'mptbm_date'
INNER JOIN {$wpdb->postmeta} pm_driver ON p.ID = pm_driver.post_id AND pm_driver.meta_key = 'mptbm_driver_name'
WHERE p.post_type = 'mptbm_booking'
  AND p.post_status = 'publish'
  AND pm_date.meta_value BETWEEN %s AND %s
  AND pm_driver.meta_value != ''
  AND pm_driver.meta_value != 'Non assigné'
GROUP BY pm_driver.meta_value
";

$query = $wpdb->prepare($sql, $start_date, $end_date);
$results = $wpdb->get_results($query);

foreach ($results as $row) {
    if (isset($driver_counts[$row->driver_name])) {
        $driver_counts[$row->driver_name] = intval($row->trip_count);
    }
}

echo json_encode([
    'labels' => $driver_names,
    'data' => array_values($driver_counts),
]);

exit();
