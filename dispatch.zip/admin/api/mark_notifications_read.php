<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;
$table = $wpdb->prefix . 'dispatch_notifications';

if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
    echo json_encode(['error' => 'Table introuvable']);
    exit;
}

$updated = $wpdb->query("UPDATE $table SET is_read = 1");

if ($updated === false) {
    echo json_encode(['success' => false, 'error' => 'Erreur lors de la mise à jour']);
} else {
    echo json_encode(['success' => true]);
}
exit;
